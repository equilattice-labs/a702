# Citeward brand guide

**Move questions forward.**

Citeward is an open research mission platform. The name joins **cite**, the evidence behind a claim, with **forward**, the progress a focused question can make. Pronounce it **SITE-werd**. A research mission connects a funded brief, public evidence, creator review and a visible outcome.

## Canonical identity

| Key | Current value |
| --- | --- |
| Display name | Citeward |
| Uppercase / slug | CITEWARD / citeward |
| Product description | An open research mission platform. |
| Tagline | Move questions forward. |
| Website package | citeward |
| Contract package | citeward-chain-contracts |
| Platform token / ticker | None. CITEWARD is a brand spelling, not a token symbol. |
| Native currency | Testnet ETH |
| Network | Robinhood Chain testnet, chain ID 46630 |
| Domain / X account | Unconfigured; no availability or ownership claim |
| Primary color | Terracotta `#B7472B`; hover `#91351F` |
| Text color | Ink `#292C25` |
| Canvas color | Warm paper `#F7F5EF`; surface `#FFFEFA` |
| Supporting colors | Olive `#465441`, sage `#DDE5D7`, pale terracotta `#F5E9E2` |
| Website typography | Georgia / Times serif for display headings; local DM Sans, registered as `Citeward Sans`, for clear interface text |
| Social typography | Georgia regular and italic with Arial interface labels on Windows; DejaVu Serif and Sans fallbacks on Linux |
| Mark | An open citation bracket and upper-right arrow on a terracotta square, with warm white and sage geometry |

## Voice and interface

Use plain, specific actions: **Explore missions**, **Create a mission**, **Submit evidence**, **Review contributions**, **Claim rewards**. Explain what the user can do next and show the mission's deadline, funding and review status where a decision is made. The interface takes its visual language from a research journal: warm paper, generous serif headings, terracotta actions, fine rules and olive annotations. Keep controls in the local sans serif so reading and acting are both clear. Research briefs, deadlines, funding and creator review form the primary information hierarchy; mobile adapts to a single column. Supporting workflow and FAQ sections explain creator review and testnet rewards.

Campaign artwork shares the journal layout: a modest masthead, large serif statements, italic terracotta emphasis, ruled columns and sage note panels. The mark preserves the citation and progress meaning of the name. SVG, avatar, banner, preview cards and the workflow video are generated from `twitter/generate_assets.py`; rendered text is checked against canvas bounds. The dated blue 3D concept image in `twitter/` is an archived concept, not part of the current publication kit.

The website must not include Twitter / X links. Locally maintained Citeward campaign assets are separate publication materials; their presence does not create a website navigation or footer destination.

Clearly distinguish sample missions, live testnet data, wallet requests and confirmed transactions. The mission creator reviews evidence and allocates escrow before the deadline; rewards are not automatic. Citeward does not issue a token or promise financial returns.

## Technical compatibility

- Keep `EvidaraEscrow`, its source filename, ABI types, function/event names and `Evidara:` revert prefix. These are technical compatibility details.
- Current saved missions use `citeward-saved`. Preserve `civiquill-saved` and `proofora-saved` as legacy migration keys, with isolated sample and chain/address namespaces.
- Keep `VITE_CONTRACT_ADDRESS`, `VITE_CHAIN_ID`, `VITE_RPC_URL`, `VITE_EXPLORER_URL`, `ROBINHOOD_RPC_URL`, `ROBINHOOD_CHAIN_ID`, `DEPLOYER_PRIVATE_KEY` and all existing configuration interfaces.
- Keep the recorded deployment at `0x58484BB53186904d65C23fb5c58C3BF191b3cD62`, chain ID 46630, RPC/explorer URLs and current `contracts/deployment.json`. Local validation does not prove that a recorded address runs current source.
- The current naming rationale is [REBRAND-NAMING-CITEWARD.md](REBRAND-NAMING-CITEWARD.md). Current browser evidence and project checks are linked in [RESKIN-VALIDATION.md](RESKIN-VALIDATION.md).

The Citeward choice is a local product identity decision. No domain or handle availability checks, trademark clearance, registration, publication, deployment or asset migration are implied. Current launch materials use no unverified domain or social account.
