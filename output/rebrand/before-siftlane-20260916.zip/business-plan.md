# Citeward - Business Plan

**Move questions forward.**

## Executive thesis

Citeward is an open research mission platform on Robinhood Chain testnet. Anyone can fund a question with native testnet ETH, contributors submit evidence links, and the mission creator approves awards on-chain. The result is a public record of questions, contributions and payouts that communities can inspect and reuse.

## The problem

Useful research is scattered across feeds, documents and dashboards. Communities struggle to fund focused questions, credit contributors and preserve the evidence behind an answer. A shared mission board gives each question a brief, a deadline, a funded reward and an accountable reviewer.

## Product and experience

- **Mission board:** discover questions by topic and status, with funding and deadlines visible before opening a mission.
- **Fund a question:** publish a title, brief URI, category, deadline and positive testnet ETH bounty. Additional funding can be added while the mission is open.
- **Evidence workspace:** inspect the brief, submit a source URI and review public contributions. The mission creator decides which submissions to approve and how much to award before the deadline.
- **Rewards:** approved amounts become claimable balances. Contributors withdraw through a separate wallet transaction; unallocated funds can be credited back to the creator after the deadline and then claimed.

The Citeward interface follows a research journal, using warm paper, terracotta, olive and sage with a citation bracket and upper-right arrow. A serif introduction and source-note illustration lead into two columns of mission cards on desktop, horizontal topic filters and a single column on mobile. The featured mission remains independent of collection filters; clear-search controls and removable filter chips make it easy to recover from a narrow search. Serif headings establish a reading hierarchy while local DM Sans keeps funding, deadlines and actions easy to scan. Navigation follows the work: discover a question, understand its brief, contribute evidence, then review or claim. Sample content is identified explicitly, and transaction feedback distinguishes wallet approval, confirmation and failure. The application requires a configured, verified contract before write actions are available. Website navigation contains no Twitter / X links.

## Audience and initial focus

1. Researchers who already share source-based analysis and dashboards.
2. Communities that want to fund public questions with transparent escrow.
3. Builders looking for testnet feedback and documented research contributions.

The initial pilot is a 30-day research program with a target of 25 funded missions. Its purpose is to learn whether clear briefs, timely creator reviews and reusable evidence make contributors return. These are proposed targets, not traction claims.

## Business model

The current escrow contract charges no platform fee. A future coordination fee, paid community tooling or hosted indexing may support the service, subject to evidence of demand. Fee collection and governance would require additional design and implementation; the present contract does not expose fee or governance controls.

## Token and incentives

Citeward issues no platform token. Native testnet ETH pays gas and funds escrow. Approved evidence and public transaction records can support a contributor portfolio; reputation attestations and curation roles are future product work. Testnet rewards are for experimenting with the workflow and carry no promise of financial return.

## Go-to-market

Publish clear mission themes, recruit independent researchers and share completed evidence summaries. Offer creators brief templates and practical review guidance. Potential outreach includes research communities, wallets and Robinhood Chain builders; no partnership is claimed. Social drafts and visual assets are local launch materials until publication is separately authorized.

## Roadmap

- **Testnet pilot:** validate the escrow, mission discovery, wallet flow, submission and creator review with 25 proposed missions.
- **Research portfolios:** improve contribution discovery, indexing and notifications.
- **Community tools:** explore curator roles, attestations and reusable mission templates.
- **Open integration:** document an SDK and community-hosted Citeward boards after the core workflow is proven.

## Risks and controls

The current contract has no upgrade hook or emergency pause. It uses pull-based withdrawals and prevents creators from reclaiming approved awards. Review is creator-controlled and must happen before the deadline, so clear briefs and active reviewers matter. An independent audit, operational monitoring and deployment verification are prerequisites for any mainnet release. No mainnet deployment is part of this rebrand.

## Success metrics

Track funded missions, evidence approval rate, median time to first contribution, median review time, repeat contributor rate, unique mission creators and testnet ETH settled. A later proposed milestone is 100 funded missions, 60% repeat contributors and a median review time below 24 hours. No current adoption numbers are asserted.

## Identity and availability

The selected brand is **Citeward**, with the tagline **Move questions forward.** Current identity rules are in `BRANDING.md`, and the decision is recorded in `REBRAND-NAMING-CITEWARD.md`. No domain, X username or trademark availability checks were performed for this choice. Launch links remain unconfigured until verified.

## Testnet notice

Citeward is experimental software for research coordination on Robinhood Chain testnet. Nothing in these materials is investment, trading or financial advice. Verify the configured network and deployed contract before using a wallet.
