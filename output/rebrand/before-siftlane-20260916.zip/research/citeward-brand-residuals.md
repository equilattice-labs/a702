# Citeward text identity audit

Generated at 2026-09-15T16:12:26.808795+00:00. Scanned 73 public UTF-8 text files; found 97 matching lines and 0 unresolved lines.

Run from the workspace root: `python research/check-citeward-brand.py`.

The JSON report records every match with file, line, classification and source text, plus hashes of scanned files. This is a source audit; browser, build and media verification are recorded separately.

| Classification | Matching lines |
| --- | --- |
| intentional_technical_compatibility | 97 |

## Intentional preservation

- `EvidaraEscrow`, ABI types/imports and `Evidara:` revert prefixes retain contract compatibility.
- `civiquill-saved` and `proofora-saved` retain existing bookmarks through migration.

## Exclusions

Private configuration and credential filenames, dependencies, Git metadata, browser output, build output, compiler artifacts/caches, video frames, font vendor files and binary media are excluded before file content is opened. The audit script and its reports are excluded to prevent self-matches. Historical folders have no blanket exemption.

## Unresolved matches

None. Remaining old aliases are classified by the explicit preservation rules above.
