# Citeward brand verification

The active project brand is **Citeward**. Current identity and launch rules live in [BRANDING.md](../BRANDING.md).

- [REBRAND-NAMING-CITEWARD.md](../REBRAND-NAMING-CITEWARD.md) explains the current name and positioning; no domain, X account or trademark availability checks were performed for Citeward.
- `check-citeward-brand.py` checks active source and materials for inconsistent brand references while allowing required technical compatibility identifiers. It exits with status 1 when an unresolved reference remains.
- `citeward-brand-residuals.md` records the latest brand audit.

Current interface evidence is in `../website/output/playwright/` and linked from [RESKIN-VALIDATION.md](../RESKIN-VALIDATION.md).
