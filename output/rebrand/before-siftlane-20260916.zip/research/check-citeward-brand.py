"""Read-only text identity audit; writes its JSON and Markdown reports in research/."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / 'research/citeward-brand-residuals.json'
SUMMARY = ROOT / 'research/citeward-brand-residuals.md'
TEXT_SUFFIXES = {'.md', '.txt', '.js', '.mjs', '.cjs', '.ts', '.vue', '.css', '.html', '.json', '.py', '.sol', '.svg'}
EXCLUDED_DIRS = {'node_modules', '.git', '.codex', 'output', 'dist', 'artifacts', 'cache', 'frames', 'fonts', '.playwright-cli', '__pycache__'}
EXCLUDED_FILES = {'research/check-citeward-brand.py', 'research/citeward-brand-residuals.json', 'research/citeward-brand-residuals.md'}
PATTERN = re.compile(r'civiquill|proofora|evidara|Good questions\. Public knowledge\.|Research, with receipts\.|Fund questions\. Share evidence\.|#183e36|#f6f7f2|#d4ec89|#2449e8|#17203a|#f7f8fc|#e7f588', re.I)
TECHNICAL = re.compile(r'EvidaraEscrow|Evidara:|civiquill-saved|proofora-saved', re.I)


def excluded(path):
    parts = path.parts
    name = path.name.lower()
    relative = path.as_posix()
    if path.suffix.lower() not in TEXT_SUFFIXES:
        return True
    if any(part.lower() in EXCLUDED_DIRS for part in parts[:-1]):
        return True
    if relative in EXCLUDED_FILES:
        return True
    if name.startswith('.env') or name == 'key.txt' or 'secret' in name or 'credential' in name:
        return True
    if path.suffix.lower() in {'.pem', '.key', '.p12', '.pfx'}:
        return True
    return False


def classify(relative, line):
    remainder = TECHNICAL.sub('', line)
    if not PATTERN.search(remainder):
        return 'intentional_technical_compatibility'
    if relative.startswith('website/a702/'):
        return 'unresolved_mirror_residual'
    if relative == 'RESKIN-VALIDATION.md':
        return 'unresolved_validation_report_residual'
    return 'unresolved_active_residual'


# Use rg to inventory filenames, then apply the safety filter before opening any file.
inventory = subprocess.run(['rg', '--files', '--hidden'], cwd=ROOT, check=True, capture_output=True, text=True, encoding='utf-8').stdout.splitlines()
files = sorted(Path(value.replace('\\', '/')) for value in inventory if not excluded(Path(value.replace('\\', '/'))))
matches = []
hashes = {}
for relative in files:
    path = ROOT / relative
    raw = path.read_bytes()
    try:
        content = raw.decode('utf-8-sig')
    except UnicodeDecodeError:
        continue
    name = relative.as_posix()
    hashes[name] = hashlib.sha256(raw).hexdigest()
    for number, line in enumerate(content.splitlines(), 1):
        tokens = [match.group() for match in PATTERN.finditer(line)]
        if tokens:
            matches.append({'file': name, 'line': number, 'tokens': tokens, 'classification': classify(name, line), 'text': line})

counts = dict(Counter(match['classification'] for match in matches))
unresolved = [match for match in matches if match['classification'].startswith('unresolved_')]
report = {
    'brand': 'Citeward',
    'generated_at_utc': datetime.now(timezone.utc).isoformat(),
    'scope': 'Current public text sources, manifests, metadata, documentation and vector assets; main website and a702 mirror included.',
    'search_pattern': PATTERN.pattern,
    'excluded': {
        'directories': sorted(EXCLUDED_DIRS),
        'files': sorted(EXCLUDED_FILES) + ['.env*', 'key.txt', '*secret*', '*credential*', '*.pem', '*.key', '*.p12', '*.pfx'],
        'other': 'Binary media and non-text extensions are excluded. Excluded files are not opened.',
    },
    'intentional_preserve_rules': {
        'technical': 'EvidaraEscrow names/types/ABI imports, Evidara: revert prefixes, civiquill-saved and proofora-saved migration keys.',
    },
    'scanned_utf8_files': len(hashes),
    'matched_lines': len(matches),
    'classification_counts': counts,
    'unresolved_lines': len(unresolved),
    'passed': len(unresolved) == 0,
    'matches': matches,
    'scanned_file_sha256': hashes,
}
REPORT.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
lines = [
    '# Citeward text identity audit', '',
    f"Generated at {report['generated_at_utc']}. Scanned {len(hashes)} public UTF-8 text files; found {len(matches)} matching lines and {len(unresolved)} unresolved lines.", '',
    'Run from the workspace root: `python research/check-citeward-brand.py`.', '',
    'The JSON report records every match with file, line, classification and source text, plus hashes of scanned files. This is a source audit; browser, build and media verification are recorded separately.', '',
    '| Classification | Matching lines |', '| --- | --- |',
]
lines += [f'| {kind} | {count} |' for kind, count in sorted(counts.items())]
lines += ['', '## Intentional preservation', '',
    '- `EvidaraEscrow`, ABI types/imports and `Evidara:` revert prefixes retain contract compatibility.',
    '- `civiquill-saved` and `proofora-saved` retain existing bookmarks through migration.',
    '',
    '## Exclusions', '',
    'Private configuration and credential filenames, dependencies, Git metadata, browser output, build output, compiler artifacts/caches, video frames, font vendor files and binary media are excluded before file content is opened. The audit script and its reports are excluded to prevent self-matches. Historical folders have no blanket exemption.', '',
    '## Unresolved matches', '',
]
if unresolved:
    grouped = Counter(match['file'] for match in unresolved)
    lines += ['| File | Unresolved lines |', '| --- | --- |']
    lines += [f'| `{name}` | {count} |' for name, count in sorted(grouped.items())]
else:
    lines.append('None. Remaining old aliases are classified by the explicit preservation rules above.')
SUMMARY.write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(json.dumps({'scanned_files': len(hashes), 'matched_lines': len(matches), 'unresolved_lines': len(unresolved), 'classification_counts': counts, 'report': REPORT.relative_to(ROOT).as_posix()}))
raise SystemExit(1 if unresolved else 0)
