# Citeward 品牌与体验重构验收

2026-09-15—16（Asia/Shanghai）。按 `rebrand`、`reskin` skill 完成本地品牌表达与整站体验重构。本轮沿用仓库已有的 **Citeward / Move questions forward.**，完整设计规范见 [BRANDING.md](BRANDING.md)。

## 本轮交付

- 将深色首屏、主题侧栏和横向列表重构为暖纸研究期刊：衬线标题、陶土红操作、橄榄绿状态、鼠尾草插画，桌面双列任务卡与横向主题筛选，手机单列布局。
- 首屏推荐卡直接打开已读取集合的第一项任务，独立于下方的搜索、排序与收藏视图。加载、读取失败和真实空集合均有对应反馈，不显示过期推荐入口。
- 搜索增加明确清除按钮，清除后保持主题并恢复输入焦点；当前主题和关键词可逐项移除，也可同时重置。保留四种排序、收藏持久化与个人创建任务视图。
- 详情的 Brief / Contribute / Review 使用关联的 `tablist`、`tab`、`tabpanel`，支持方向键、Home / End、单一 Tab 停靠点。保留 Escape、焦点返回和移动菜单焦点约束。
- 两步创建、草稿校验与下载、贡献、资助、审核、退款和奖励面板统一使用新样式。金额输入仍保留完整十进制字符串，精确到 1 wei。
- 新增 `ResearchCover.vue`、`MissionCard.vue`，展示层与原有业务 composable 分离；卡片和奖励面板共用 `src/utils/format.js`。样式入口集中引用 `editorial.css` 和 `dialogs.css`。
- 重绘标识、头像、横幅、Open Graph 分享图、任务流程图、工具图和 10 秒视频；同步品牌规范、命名说明、商业计划、网站及传播文档。SVG、PNG 和视频均可由本地脚本再生成。
- 主站与 `a702` 分发入口完成同步和生产构建；保留相对资源路径和独立环境配置。

## 兼容范围

发布、资助、提交证据、创建者审批、到期退回未分配余额、领取奖励六种合约行为保持兼容。审批必须在截止前完成；截止后未分配余额转入创建者可领取余额，其他资助者不具有单独退款权。

`EvidaraEscrow`、ABI、`Evidara:` revert 前缀、部署记录、链 ID 46630、RPC / explorer 与环境变量接口保留。`civiquill-saved` / `proofora-saved` 保留为旧收藏迁移键。Citeward 没有平台代币，奖励仍为测试网 ETH。

## 验证结果

| 检查 | 结果 |
| --- | --- |
| `npm run check:logic` | 4 组、99 个断言通过，涵盖六类交易、精度、权限、收藏迁移和读取错误 |
| `npm run build:all` | 主站和 a702 均构建成功，生产 JS / CSS 文件名及内容一致 |
| `npm run check:site` | 135 项通过：品牌、资源引用、禁止社交外链 / 元数据、主站与镜像一致性 |
| `npm --prefix contracts test -- --network hardhat` | 本地合约 7 个测试通过 |
| `npm run check:ui` | 7 组流程通过：推荐入口、筛选、排序、收藏、详情、创建校验 / 编辑 / 下载、缺失钱包反馈、指南、奖励和 FAQ |
| `npm run check:live` | 7 组隔离 RPC 流程通过：加载、审批权限及金额、截止状态、危险 URL、读取失败 / 重试、真实空集合和切网后的奖励展示 |
| 响应式 | 320 / 390 / 768 / 1024 / 1440 / 1920 px：无横向溢出，首屏主操作可见 |
| axe | WCAG 2 A/AA、2.1 AA：页面 320 / 390 / 1440、桌面详情、手机创建、创建者审核共 6 个状态，均 0 违规 |
| `npm run check:experience` | 390×844、isMobile / hasTouch：搜索清除保留主题、收藏详情返回、非法 URL 恢复及精确 1 wei 草稿下载通过 |
| 内容和输入适配 | 长标题、描述、金额、筛选关键词和详情标题人工注入后无横向溢出；减弱动效与强制色彩通过 |
| 资源稳定性 | 字体、标识及首屏资源成功加载，正常页面无 JavaScript 异常；测试浏览器无外部请求 |

验收中修复了浅陶土标签小字号对比度不足，以及组件拆分后奖励面板的金额格式化引用遗漏。响应式脚本在变更视口后等待两帧布局完成，避免把断点切换中间状态误判为页面溢出。

## 资源与性能

当前生产 JS **394.17 kB / gzip 141.79 kB**，CSS **41.64 kB / gzip 9.17 kB**。上版已有验收记录为 JS 390.30 / gzip 140.58 kB、CSS 38.23 / gzip 8.37 kB；本轮增加的压缩资源约 2.01 kB，包含推荐任务状态、独立筛选操作、键盘页签和新布局。

最新生产构建：`index-BO-mG4N9.js`、`index-CNE3oU6t.css`。新建浏览器上下文、1440×1000、无网络节流的本机预览测得 FCP / LCP **292 ms**，CLS **0**；首屏子资源传输 188,336 bytes。上版记录的 256 ms 来自另一轮采样，不能据此推断真实性能趋势。未测量真实设备、弱网或生产站点的用户指标。

## 截图与可复现证据

- [本轮改版前基线](website/output/playwright/citeward-baseline-20260915.png)
- [当前桌面](website/output/playwright/citeward-1440.png) / [当前手机](website/output/playwright/citeward-390.png) / [桌面整页](website/output/playwright/citeward-full-desktop.png)
- [手机详情](website/output/playwright/citeward-detail-mobile.png) / [手机创建](website/output/playwright/citeward-create-mobile.png)
- [创建者审核](website/output/playwright/citeward-creator-review.png) / [RPC 失败](website/output/playwright/citeward-rpc-error.png) / [强制色彩](website/output/playwright/citeward-forced-colors.png)
- [页面、响应式和 axe 结果](website/output/playwright/citeward-ui-results.json)
- [隔离 RPC 结果](website/output/playwright/citeward-live-results.json)
- [资源、性能与触摸体验记录](website/output/playwright/citeward-experience.json)
- [品牌残留审计](research/citeward-brand-residuals.md)
- [改版前主要源码与文档快照](website/output/rebrand/citeward-before-editorial.zip)

传播套件的 5 张 PNG 可解码；SVG 与网站对应素材一致；视频为 H.264、1280×720、24 fps、10 秒。原有带日期的三维概念图保留为历史素材，未被网站引用。

## 运行与复核

```powershell
npm --prefix website install
npm --prefix website run check:logic
npm --prefix website run build:all
npm --prefix website run check:site
npm --prefix contracts test -- --network hardhat
python research/check-citeward-brand.py
```

首次浏览器验证可在 website 运行 `npx playwright install chromium`。两个终端分别启动服务，在另一终端执行浏览器验收：

```powershell
npm --prefix website run preview -- --host 127.0.0.1 --port 42702 --strictPort
npm --prefix website run dev -- --host 127.0.0.1 --port 5173 --strictPort
# 服务就绪后：
npm --prefix website run check:ui
npm --prefix website run check:live
npm --prefix website run check:experience
```

生产预览地址为 `http://127.0.0.1:42702/`。浏览器交易场景仅使用隔离只读 RPC 和拒绝签名的钱包夹具；真实交易行为由逻辑 mock 和本地 Hardhat 验证。未执行外部发布或链上交易，未重新核验历史部署地址。域名与社交账号仍未配置；取得可核验的站点地址后可设置 canonical 和绝对 Open Graph URL。自动无障碍扫描不等同于辅助技术用户实测。
