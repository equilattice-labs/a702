# Citeward contract integration (ABI)

The website imports a bundled copy of `EvidaraEscrow.abi.json`. After compiling a changed contract, regenerate the exported ABI from the Hardhat artifact and synchronize the copies in both website entry points; the Vite build does not regenerate the ABI. The contract has no constructor parameters and emits indexed events for every mission, contribution, approval, claim and refund.

Core read methods: `missionCount()`, `getMission(id)`, `getMissions(cursor, limit)`, `getContribution(id, contributionId)`, `getContributions(id, cursor, limit)`, `claimable(account)`, `totalEscrowed()`, `totalAwarded()`, `totalClaimed()`.

Core writes (ethers v6):
- `createMission(title, descriptionURI, category, deadline, { value })`
- `fundMission(id, { value })`
- `contribute(id, evidenceURI)`
- `approveContribution(id, contributionId, amount)` (mission creator)
- `claimRewards()`
- `refundUnallocated(id)` (mission creator, after deadline)

The website should display amounts in native ETH using `formatEther` and ask users to switch to the configured Robinhood testnet chain before writes.

The display brand is Citeward. The existing deployment address, `EvidaraEscrow` identifier, ABI and `Evidara:` revert strings remain unchanged for compatibility. This local brand update does not require a replacement deployment and does not prove that the recorded deployment matches the current source. Confirm the address and deployed bytecode before enabling writes. Local validation results and their reproducibility limits are recorded in [REBRAND-VALIDATION.md](REBRAND-VALIDATION.md).

`createMission` requires a positive testnet ETH bounty. Evidence submission, additional funding and creator approvals are available only before the deadline while the mission is open. `refundUnallocated` is creator-only after the deadline and credits their claimable balance; it does not transfer ETH until `claimRewards()` is called.
