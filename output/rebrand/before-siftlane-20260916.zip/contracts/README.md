# Citeward Chain contract

`EvidaraEscrow` is a single-address mission registry and native testnet ETH bounty escrow. Researchers publish missions, contributors attach evidence URIs, and the mission creator approves fixed awards. Approved awards become pull-based claims. Unallocated funds can be refunded by the creator after the deadline. There is no token, transfer tax, upgrade hook, or investment/yield promise.

**Brand and deployment status:** Citeward is the display brand. The existing `EvidaraEscrow` identifier, ABI, `Evidara:` revert strings and testnet deployment address in `deployment.json` remain unchanged. Solidity edits changed the display comment only; no contract was deployed or migrated. Local validation results and their reproducibility limits are recorded in [REBRAND-VALIDATION.md](REBRAND-VALIDATION.md). Verify the configured address and deployed bytecode before enabling wallet writes; the deployment record alone does not verify a deployment against the current source.

## Deploy to Robinhood testnet

1. Copy `.env.example` to `.env` and set `ROBINHOOD_RPC_URL`, `ROBINHOOD_CHAIN_ID`, and `DEPLOYER_PRIVATE_KEY`. Use a dedicated testnet key; never commit `.env`.
2. Install and compile: `npm install` then `npm run compile`.
3. Deploy with `npm run deploy:testnet`.

The script prints the deployed address. Set the verified address through the website's existing `VITE_CONTRACT_ADDRESS` setting and use the exported ABI before enabling wallet actions. `website-config.example.ts` illustrates the ABI and network configuration for a separate integration. The deployer only needs a funded testnet private key; no constructor arguments are required. Deployment is a separate release action and was not run for this brand update.

Typical flow: `createMission(title, descriptionURI, category, deadline)` with a positive native testnet ETH bounty, `contribute(missionId, evidenceURI)`, creator `approveContribution(missionId, contributionId, amount)` before the deadline, then contributor `claimRewards()`. After a deadline, the creator may call `refundUnallocated(missionId)`, which credits unallocated funds to their claimable balance; `claimRewards()` then withdraws them.
