"""Build Citeward's research journal social kit from local geometry and type.

Run: python twitter/generate_assets.py --encode
Requires Pillow and ffmpeg. No network, account, or deployment access is used.
Use --sync-public to also copy the mark and social preview to website/public.
"""
from pathlib import Path
import argparse
import shutil
import subprocess
from PIL import Image, ImageDraw, ImageFont

OUT = Path(__file__).resolve().parent
PUBLIC = OUT.parent / 'website' / 'public'
TERRA, INK, PAPER, SAGE = '#B7472B', '#292C25', '#F7F5EF', '#DDE5D7'
OLIVE, PALE_TERRA, WHITE = '#465441', '#F5E9E2', '#FFFEFA'
MUTED, LINE = '#686B62', '#CFD0C6'
FPS, FRAMES = 24, 240
FONT_PATHS = {
    'body': ['C:/Windows/Fonts/arial.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'],
    'bold': ['C:/Windows/Fonts/arialbd.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'],
    'serif': ['C:/Windows/Fonts/georgia.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf'],
    'italic': ['C:/Windows/Fonts/georgiai.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSerif-Italic.ttf'],
}
FONT_CACHE = {}


def font(size, family='body'):
    key = size, family
    if key not in FONT_CACHE:
        path = next((p for p in FONT_PATHS[family] if Path(p).exists()), None)
        if not path:
            raise RuntimeError(f'No supported {family} font found; edit FONT_PATHS.')
        FONT_CACHE[key] = ImageFont.truetype(path, size)
    return FONT_CACHE[key]


def canvas(w, h, color=PAPER):
    im = Image.new('RGB', (w, h), color)
    return im, ImageDraw.Draw(im)


def text(d, value, xy, size=24, color=INK, family='body', anchor='lt'):
    bounds = d.textbbox(xy, value, font=font(size, family), anchor=anchor)
    w, h = d._image.size
    if bounds[0] < 0 or bounds[1] < 0 or bounds[2] > w or bounds[3] > h:
        raise ValueError(f'Text outside canvas: {value!r}, bounds={bounds}, canvas={w}x{h}')
    d.text(xy, value, font=font(size, family), fill=color, anchor=anchor)


def lines(d, values, xy, size=24, color=INK, family='body', leading=None):
    for i, value in enumerate(values):
        text(d, value, (xy[0], xy[1] + i * (leading or round(size * 1.28))), size, color, family)


def label(d, value, xy, color=MUTED, size=14):
    text(d, value, xy, size, color, 'bold')


def arrow(d, xy, size, color=TERRA, width=None):
    x, y = xy
    width = width or max(3, round(size * .12))
    # Square ends echo a source citation's brackets.
    d.line((x, y + size, x + size, y), fill=color, width=width)
    d.line((x + size * .24, y, x + size, y, x + size, y + size * .76), fill=color, width=width, joint='curve')


def geometry(d, origin, scale, bracket=WHITE, pointer=SAGE):
    x, y = origin
    def polygon(points, color):
        d.polygon([(x + a * scale, y + b * scale) for a, b in points], fill=color)
    polygon([(26,15),(14,15),(14,49),(26,49),(26,43),(20,43),(20,21),(26,21)], bracket)
    polygon([(32,18),(50,18),(50,36),(44,36),(44,28),(31,41),(27,37),(40,24),(32,24)], pointer)


def symbol(size=128, background=TERRA, bracket=WHITE, pointer=SAGE):
    # Supersampled geometry is shared with citeward-mark.svg.
    factor = 4
    im = Image.new('RGBA', (size * factor, size * factor), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    s = size * factor / 64
    if background:
        d.rounded_rectangle((0, 0, size * factor - 1, size * factor - 1), radius=4*s, fill=background)
    geometry(d, (0, 0), s, bracket, pointer)
    return im.resize((size, size), Image.Resampling.LANCZOS)


def brand(im, xy=(56, 44), size=42, color=INK, tile=True):
    mark = symbol(size, TERRA if tile else None, WHITE if tile else INK, SAGE if tile else TERRA)
    im.paste(mark, xy, mark)
    text(ImageDraw.Draw(im), 'Citeward', (xy[0] + size + 12, xy[1] + size / 2), round(size*.80), color, 'serif', 'lm')


def footer(d, y, width, left='OPEN RESEARCH / SHARED EVIDENCE', color=MUTED):
    d.line((54, y, width-54, y), fill=LINE, width=1)
    label(d, left, (55, y+22), color, 12)
    text(d, 'ROBINHOOD CHAIN TESTNET', (width-55, y+22), 12, color, 'bold', 'rt')


def write_vector():
    (OUT / 'citeward-mark.svg').write_text('''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" role="img" aria-labelledby="title desc">
  <title id="title">Citeward</title>
  <desc id="desc">A warm white citation bracket and sage advance arrow on a terracotta square.</desc>
  <rect width="64" height="64" rx="4" fill="#B7472B"/>
  <path d="M26 15H14V49H26V43H20V21H26Z" fill="#FFFEFA"/>
  <path d="M32 18H50V36H44V28L31 41L27 37L40 24H32Z" fill="#DDE5D7"/>
</svg>
''', encoding='utf-8')


def logo():
    im, d = canvas(800, 800, TERRA)
    geometry(d, (0, 0), 12.5)
    im.save(OUT / 'logo.png')


def banner():
    im, d = canvas(1500, 500)
    brand(im, (56, 33), 46)
    text(d, 'AN OPEN RESEARCH JOURNAL', (1444, 56), 13, OLIVE, 'bold', 'rm')
    d.line((56, 104, 1444, 104), fill=INK, width=1)
    text(d, 'Move questions', (56, 142), 85, INK, 'serif')
    text(d, 'forward.', (58, 236), 89, TERRA, 'italic')
    d.line((883, 137, 883, 363), fill=LINE, width=1)
    label(d, 'A PRACTICE OF SHARED DISCOVERY', (930, 150), OLIVE, 13)
    lines(d, ['A focused question.', 'Evidence with context.', 'Research that moves.'], (930, 198), 30, INK, 'serif', 48)
    arrow(d, (1398, 328), 35, TERRA, 4)
    d.rectangle((0, 407, 1500, 500), fill=SAGE)
    label(d, 'BRIEF   /   EVIDENCE   /   REVIEW   /   REWARD', (57, 446), OLIVE, 15)
    text(d, 'Robinhood Chain Testnet / Native testnet ETH', (1444, 454), 15, OLIVE, anchor='rm')
    im.save(OUT / 'banner.png')


def social():
    im, d = canvas(1200, 630)
    brand(im, (54, 37), 44)
    text(d, 'OPEN RESEARCH / SHARED EVIDENCE', (1146, 59), 12, OLIVE, 'bold', 'rm')
    d.line((54, 107, 1146, 107), fill=INK, width=1)
    label(d, 'THE NEXT QUESTION STARTS HERE', (56, 146), OLIVE, 12)
    text(d, 'Move questions', (51, 197), 73, INK, 'serif')
    text(d, 'forward.', (54, 282), 80, TERRA, 'italic')
    lines(d, ['Fund a brief. Contribute evidence.', 'Give useful research a way forward.'], (57, 421), 22, MUTED, leading=35)
    d.rectangle((783, 146, 1146, 500), fill=SAGE)
    label(d, 'THE RESEARCH PRACTICE', (808, 172), OLIVE, 12)
    for i, title in enumerate(['A focused brief', 'Sources & context', 'Creator review']):
        y = 226 + i * 72
        d.line((808, y-13, 1120, y-13), fill='#B7C2AE', width=1)
        text(d, '0'+str(i+1), (809, y+5), 15, OLIVE, 'body')
        text(d, title, (849, y), 21, INK, 'serif')
    arrow(d, (1087, 439), 31, TERRA, 4)
    footer(d, 550, 1200)
    im.save(OUT / 'citeward-social.png')


def mission():
    im, d = canvas(1200, 675)
    brand(im, (53, 36), 43)
    text(d, 'FIELD GUIDE / THE MISSION WORKFLOW', (1146, 58), 12, OLIVE, 'bold', 'rm')
    d.line((54, 108, 1146, 108), fill=INK, width=1)
    label(d, 'FROM A QUESTION TO A CONTRIBUTION', (55, 139), OLIVE, 12)
    text(d, 'Bring a question.', (53, 180), 51, INK, 'serif')
    text(d, 'Build on evidence.', (490, 180), 51, TERRA, 'italic')
    steps = [
        ('01', 'Read the brief', ['Start with the question,', 'scope and testnet bounty.']),
        ('02', 'Add evidence', ['Submit sources with', 'your reasoning and context.']),
        ('03', 'Creator review', ['The creator reviews and', 'selects contributions.']),
        ('04', 'Claim a reward', ['Selected contributors', 'withdraw testnet ETH.']),
    ]
    for i, (num, title, body) in enumerate(steps):
        x = 54 + i * 280
        text(d, num, (x, 288), 55, TERRA, 'serif')
        if i < 3:
            d.line((x+94, 325, x+236, 325), fill=LINE, width=1)
            arrow(d, (x+225, 316), 16, OLIVE, 2)
        text(d, title, (x, 383), 24, INK, 'serif')
        lines(d, body, (x, 432), 18, MUTED, leading=29)
    d.rectangle((54, 532, 1147, 581), fill=SAGE)
    text(d, 'Useful evidence moves the work forward.', (77, 548), 17, OLIVE, 'body')
    footer(d, 607, 1200, 'ILLUSTRATIVE WORKFLOW / TESTNET ONLY')
    im.save(OUT / 'mission-card.png')


def primitives():
    im, d = canvas(1200, 675)
    brand(im, (53, 37), 43)
    text(d, 'THE CITEWARD RESEARCH PRACTICE', (1146, 58), 12, OLIVE, 'bold', 'rm')
    d.line((54, 108, 1146, 108), fill=INK, width=1)
    text(d, 'Make research move.', (51, 146), 59, INK, 'serif')
    items = [
        ('01', 'A focused brief', ['Define a question and scope.', 'Fund it with native', 'testnet ETH.']),
        ('02', 'Evidence + context', ['Link your sources.', 'Explain what they show.', 'Make your reasoning clear.']),
        ('03', 'Review + reward', ['The creator selects work.', 'Selected contributors', 'withdraw their rewards.']),
    ]
    for i, (num, title, body) in enumerate(items):
        x = 54 + i * 371
        d.rectangle((x, 262, x+351, 543), fill=[PALE_TERRA, SAGE, WHITE][i])
        label(d, '[' + num + ']', (x+25, 289), OLIVE, 14)
        arrow(d, (x+295, 288), 22, TERRA, 3)
        text(d, title, (x+25, 349), 25, INK, 'serif')
        lines(d, body, (x+25, 408), 18, MUTED, leading=29)
    footer(d, 598, 1200, 'THREE TOOLS / ONE SHARED QUESTION')
    im.save(OUT / 'primitives.png')


STAGES = [
    ('01', 'Fund a question.', 'Give research a focused place to begin.', 'RESEARCH BRIEF', ['A clear question', 'A defined scope', 'A native testnet ETH bounty'], 'CREATOR'),
    ('02', 'Build an answer.', 'Put sources and context behind your reasoning.', 'CONTRIBUTION', ['Source-backed evidence', 'A clear explanation', 'Context others can follow'], 'CONTRIBUTOR'),
    ('03', 'Review the work.', 'The creator selects useful contributions.', 'CREATOR REVIEW', ['Read the reasoning', 'Examine the sources', 'Select contributions'], 'CREATOR'),
    ('04', 'Claim a reward.', 'Selected contributors withdraw testnet ETH.', 'WITHDRAWAL', ['Contribution selected', 'Reward made available', 'Contributor withdraws'], 'CONTRIBUTOR'),
]


def video_frame(index):
    stage, phase = min(index // 60, 3), (index % 60) / 59
    num, title, subtitle, card_title, body, role = STAGES[stage]
    im, d = canvas(1280, 720)
    brand(im, (47, 32), 44)
    text(d, 'MOVE QUESTIONS FORWARD.', (1232, 54), 12, OLIVE, 'bold', 'rm')
    d.line((48, 105, 1232, 105), fill=INK, width=1)
    label(d, 'FIELD GUIDE / THE MISSION WORKFLOW', (48, 139), OLIVE, 12)
    text(d, num, (43, 193), 104, TERRA, 'serif')
    lines(d, title.split(' ', 1), (47, 331), 45, INK, 'serif', leading=60)
    d.line((443, 140, 443, 569), fill=LINE, width=1)
    label(d, role, (49, 552), OLIVE, 12)
    text(d, card_title, (492, 146), 13, OLIVE, 'bold')
    text(d, subtitle, (490, 197), 24, INK, 'serif')
    for j, value in enumerate(body):
        y = 281 + j*94
        active = phase >= j/4
        d.rectangle((490, y-14, 1231, y+60), fill=SAGE if active else PAPER)
        d.line((490, y+60, 1231, y+60), fill=LINE, width=1)
        d.rectangle((511, y+9, 539, y+37), fill=OLIVE if active else LINE)
        if active:
            d.line((518, y+23, 524, y+29, 533, y+16), fill=WHITE, width=3)
        text(d, value, (560, y+12), 23, INK if active else MUTED)
    d.rectangle((0, 622, 1280, 720), fill=SAGE)
    for j, value in enumerate(['Fund', 'Contribute', 'Review', 'Withdraw']):
        x = 48 + j*310
        d.rectangle((x, 652, x+286, 656), fill=LINE)
        if j <= stage:
            d.rectangle((x, 652, x+max(1, round(286*(phase if j == stage else 1))), 656), fill=TERRA)
        text(d, value, (x, 674), 16, INK if j == stage else OLIVE, 'body')
    text(d, 'ROBINHOOD CHAIN TESTNET / ILLUSTRATIVE WORKFLOW', (1228, 585), 11, MUTED, 'bold', 'rt')
    return im


def encode():
    ffmpeg = shutil.which('ffmpeg')
    if not ffmpeg:
        raise RuntimeError('ffmpeg is required to encode citeward-loop.mp4')
    command = [ffmpeg, '-hide_banner', '-loglevel', 'error', '-y',
               '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', '1280x720', '-r', str(FPS),
               '-i', 'pipe:0', '-frames:v', str(FRAMES),
               '-c:v', 'libx264', '-crf', '18', '-pix_fmt', 'yuv420p', '-movflags', '+faststart',
               str(OUT / 'citeward-loop.mp4')]
    with subprocess.Popen(command, stdin=subprocess.PIPE) as process:
        try:
            for index in range(FRAMES):
                process.stdin.write(video_frame(index).tobytes())
        finally:
            process.stdin.close()
        if process.wait() != 0:
            raise subprocess.CalledProcessError(process.returncode, command)


def sync_public():
    PUBLIC.mkdir(exist_ok=True)
    for filename in ['citeward-mark.svg', 'citeward-social.png']:
        shutil.copyfile(OUT / filename, PUBLIC / filename)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--encode', action='store_true', help='also encode the 10-second H.264 video')
    parser.add_argument('--sync-public', action='store_true', help='also copy the mark and preview into website/public')
    args = parser.parse_args()
    write_vector()
    logo()
    banner()
    social()
    mission()
    primitives()
    if args.encode:
        encode()
    if args.sync_public:
        sync_public()
    print('Citeward: 5 PNG assets and SVG mark' + (', plus MP4 regenerated without frame files.' if args.encode else ' regenerated.'))
