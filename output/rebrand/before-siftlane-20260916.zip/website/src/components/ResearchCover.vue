<script setup>
import UiIcon from "./UiIcon.vue";
defineProps({
  mission: { type: Object, default: null },
  loading: Boolean,
  error: { type: String, default: "" },
});
defineEmits(["explore", "create", "open", "retry"]);
</script>

<template>
  <section class="hero" aria-labelledby="hero-title">
    <div class="hero-copy">
      <div class="eyebrow">
        <span class="label-dash"></span>AN OPEN FIELD FOR CURIOUS MINDS
      </div>
      <h1 id="hero-title">
        Move questions<br /><em>forward.</em
        ><span class="headline-arrow" aria-hidden="true">↗</span>
      </h1>
      <p>
        A question worth asking. Evidence worth sharing.<br
          class="desktop-break"
        />
        Fund focused research and build knowledge in the open.
      </p>
      <div class="hero-actions">
        <button class="button primary" @click="$emit('explore')">
          Explore missions<UiIcon name="arrow" :size="18" />
        </button>
        <button class="text-button" @click="$emit('create')">
          Create a mission<UiIcon name="plus" :size="17" />
        </button>
      </div>
      <div class="hero-caption">
        <span class="caption-rule"></span>Independent questions. Shared
        discoveries.
      </div>
    </div>
    <div class="field-note">
      <div class="field-note-heading">
        <span>CITEWARD FIELDNOTES</span><span aria-hidden="true">[ ↗ ]</span>
      </div>
      <div class="evidence-art" aria-hidden="true">
        <div class="orbit orbit-one"></div>
        <div class="orbit orbit-two"></div>
        <span class="art-coordinate coordinate-top">QUESTION → EVIDENCE</span>
        <div class="source-sheet sheet-back">
          <span>02 / THE SOURCE</span><i></i><i></i><i></i>
        </div>
        <div class="source-sheet sheet-front">
          <span>01 / THE QUESTION</span
          ><b>What if<br />we looked<br /><em>closer?</em></b
          ><span class="sheet-arrow">↗</span>
        </div>
        <span class="citation-stamp">OPEN<br />BY DESIGN</span>
        <span class="art-coordinate coordinate-bottom"
          >FOLLOW THE SOURCES.</span
        >
      </div>
      <div v-if="loading" class="featured-brief featured-status" role="status">
        <span class="spinner"></span>Finding the next question…
      </div>
      <div v-else-if="error" class="featured-brief featured-status">
        <p>Research is a little out of reach.</p>
        <button class="text-button" @click="$emit('retry')">
          Retry loading<UiIcon name="refresh" :size="16" />
        </button>
      </div>
      <button
        v-else-if="mission"
        class="featured-brief"
        aria-label="Open featured mission"
        @click="$emit('open', mission)"
      >
        <span class="featured-label">{{
          mission.sample
            ? "FROM THE SAMPLE COLLECTION"
            : "FROM THE MISSION BOARD"
        }}</span>
        <span class="featured-title">{{ mission.title }}</span
        ><UiIcon name="arrow" :size="21" />
      </button>
      <div v-else class="featured-brief featured-status">
        <p>The next question could be yours.</p>
        <button class="text-button" @click="$emit('create')">
          Write the first brief<UiIcon name="plus" :size="16" />
        </button>
      </div>
    </div>
  </section>
</template>
