﻿# Citeward 网站重构与清理验收

2026-09-15。按 reskin、rebrand 技能完成本地修改，品牌统一为 **Citeward**，标语 **Move questions forward.**。本报告替代之前的界面验收记录；截图与机器结果均来自本轮页面。

## 界面与体验

- 从浅色大插画和两列任务卡，改为深墨色紧凑首屏、研究索引、桌面主题左栏与横向任务列表；手机使用单列。保留钴蓝、纸白、柠檬黄和本地 DM Sans 品牌体系。
- 搜索、四种排序、主题筛选、收藏、个人任务、任务详情、创建草稿、贡献、审核、奖励、指南及 FAQ 使用统一组件样式。
- 奖励与阅读入口在任务右侧并排呈现，移动端放在任务底部。44px 操作目标、移动输入至少 16px、焦点与 reduced-motion / forced-colors 处理已验证。
- 删除 Twitter 专用分享元数据；网站静态源码、公开资源及页面均无 Twitter / X / t.co 外链，保留平台无关的 Open Graph 元数据。
- 删除任务列表不使用的三个汇总 RPC，避免统计接口故障阻断已读取任务。补齐排序名称，避免错误通知与普通通知叠在同一位置。
- a702 的 src/public 改为精确同步，主站删除资源后镜像同步删除；独立环境配置不参与同步。

## 清理范围

删除 240 张可重建视频帧、重复交接便签及过时品牌摘要、两个入口的 meterial.txt 和无引用重复 abi.json、两份旧 EvidenceOrbit 组件、旧插画与卡片样式，以及 25 份过期截图、结果、第三方工具副本和下载草稿。视频生成改为直接编码，不再产生中间帧。

保留 Citeward 当前品牌规范、商业说明、有效最终 PNG/SVG/MP4、生成脚本、字体许可证、合约 ABI、部署记录和必要验证资料。保留 a702 既有分发入口。RPC 浏览器夹具从 output 迁至 scripts，与可复现验收脚本一起维护。当前截图和 JSON 是本轮验收证据。

## 保留的业务契约

发布、资助、提交证据、创建者审批、到期退回未分配余额、领取奖励六类合约行为保留。ETH 输入保留最多 18 位小数字符串。已有锚点、相对资源路径、环境配置接口、链 ID 46630、网络与部署记录保持兼容。

`EvidaraEscrow`、ABI 和 `Evidara:` 前缀作为技术兼容标识保留；`civiquill-saved` / `proofora-saved` 只用于旧收藏迁移。Citeward 没有平台代币，测试网 ETH 无预期货币价值。

## 本轮验证

| 检查 | 结果 |
| --- | --- |
| `npm run check:logic` | 4 组、99 个断言；六类交易、精度、权限、收藏迁移及统计端点不可用回归 |
| `npm run build:all` | 主站与 a702 生产构建成功，JS/CSS 文件名与内容一致 |
| `npm run check:site` | 104 项通过：品牌、本地资源、禁止社交外链/元数据、精确镜像 |
| `npm --prefix contracts test` | 7 个 Hardhat 测试通过 |
| `npm run check:ui` | 搜索空态恢复、全部主题/排序、收藏刷新与取消、详情三页签、草稿校验/编辑/下载/保留、钱包缺失、指南、奖励和全部 FAQ |
| `npm run check:live` | 隔离 RPC 的审核收款人、1 wei 输入、超额错误、非创建者权限、到期禁用/退款入口、危险 URL 回退、RPC 重试、切链 |
| 响应式 | 320 / 390 / 768 / 1024 / 1440 / 1920 px，无横向溢出，首屏主操作可见 |
| 无障碍 | axe WCAG 2 A/AA、2.1 AA：320/390/1440 页面、桌面详情、手机创建、创建者审核，共 6 个状态，均 0 违规 |
| 手机触控 | 390×844、isMobile/hasTouch：搜索清除、收藏筛选、详情贡献、创建/审核/下载精确 1 wei 草稿完成 |
| 视觉与输入 | 整页及任务、详情、创建审核、FAQ 展开、高对比度均目视检查；菜单焦点循环、Escape、焦点返回、reduced-motion 通过 |
| 加载稳定性 | 正常页无未处理脚本异常；本地字体与标识成功加载 |

当前生产 JS 390.30 kB（gzip 140.58 kB），CSS 38.23 kB（gzip 8.37 kB）。原 CSS 为 41.40 kB。新浏览器上下文、未限速本地预览测得 FCP/LCP 256 ms、CLS 0；这一结果只代表本机预览。

浏览器合约验证使用隔离只读 RPC 与钱包夹具，未发送链上交易；交易行为由逻辑 mock 与本地 Hardhat 覆盖。未重新核验历史部署地址，也未执行外部发布。自动无障碍扫描不替代辅助技术用户测试。

## 截图与机器结果

- [改版前](website/output/playwright/citeward-before.png) / [当前桌面](website/output/playwright/citeward-1440.png) / [当前手机](website/output/playwright/citeward-390.png)
- [桌面整页](website/output/playwright/citeward-full-desktop.png)
- [手机详情](website/output/playwright/citeward-detail-mobile.png) / [手机创建](website/output/playwright/citeward-create-mobile.png) / [手机草稿审核](website/output/playwright/citeward-mobile-review.png)
- [创建者审核](website/output/playwright/citeward-creator-review.png) / [RPC 失败](website/output/playwright/citeward-rpc-error.png)
- [页面、响应式与 axe 结果](website/output/playwright/citeward-ui-results.json)
- [隔离 RPC 验收结果](website/output/playwright/citeward-live-results.json)
- [资源、性能与手机触控记录](website/output/playwright/citeward-experience.json)
- [品牌残留审计](research/citeward-brand-residuals.md)

## 运行与复核

```powershell
npm --prefix website install
npm --prefix website run check:logic
npm --prefix website run build:all
npm --prefix website run check:site
npm --prefix contracts test
python research/check-citeward-brand.py
```

浏览器首次使用时在 website 运行 `npx playwright install chromium`。启动预览和开发服务器后，在另一终端运行对应验收：

```powershell
npm --prefix website run preview -- --host 127.0.0.1 --port 42702 --strictPort
npm --prefix website run dev -- --host 127.0.0.1 --port 5173 --strictPort
# 预览服务用于生产界面验收；开发服务用于替换配置模块的隔离 RPC 验收。
npm --prefix website run check:ui
npm --prefix website run check:live
```

预览地址为 `http://127.0.0.1:42702/`。未配置有效合约时会显示明确标识的样本任务；需要可核验的生产站点地址后再设置 canonical 和绝对 Open Graph URL。
