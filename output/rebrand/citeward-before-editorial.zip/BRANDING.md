# Citeward brand guide

**Move questions forward.**

Citeward is an open research mission platform. The name joins **cite**, the evidence behind a claim, with **forward**, the progress a focused question can make. Pronounce it **SITE-werd**. A research mission connects a funded brief, public evidence, creator review and a visible outcome.

## Canonical identity

| Key | Current value |
| --- | --- |
| Display name | Citeward |
| Uppercase / slug | CITEWARD / citeward |
| Product description | An open research mission platform. |
| Tagline | Move questions forward. |
| Website package | citeward |
| Contract package | citeward-chain-contracts |
| Platform token / ticker | None. CITEWARD is a brand spelling, not a token symbol. |
| Native currency | Testnet ETH |
| Network | Robinhood Chain testnet, chain ID 46630 |
| Domain / X account | Unconfigured; no availability or ownership claim |
| Primary color | Cobalt `#2449E8` |
| Text color | Ink `#17203A` |
| Canvas color | Paper `#F7F8FC` |
| Accent color | Citron `#E7F588` |
| Website typography | Local DM Sans, registered as `Citeward Sans`; bold headings and clear interface text |
| Social typography | Arial on Windows or DejaVu Sans on Linux; regular and bold weights |
| Mark | Open square brackets and an arrow moving toward the upper right |

## Voice and interface

Use plain, specific actions: **Explore missions**, **Create a mission**, **Submit evidence**, **Review contributions**, **Claim rewards**. Explain what the user can do next and show the mission's deadline, funding and review status where a decision is made. The interface uses a compact ink-colored hero, a research index drawn in HTML/CSS, cobalt actions and a clear typographic hierarchy. On desktop, topic navigation sits beside horizontal mission entries so research briefs, deadlines and funding are easy to compare. Mobile uses a single column. Supporting workflow and FAQ sections explain creator review and testnet rewards.

The website must not include Twitter / X links. Locally maintained Citeward campaign assets are separate publication materials; their presence does not create a website navigation or footer destination.

Clearly distinguish sample missions, live testnet data, wallet requests and confirmed transactions. The mission creator reviews evidence and allocates escrow before the deadline; rewards are not automatic. Citeward does not issue a token or promise financial returns.

## Technical compatibility

- Keep `EvidaraEscrow`, its source filename, ABI types, function/event names and `Evidara:` revert prefix. These are technical compatibility details.
- Current saved missions use `citeward-saved`. Preserve `civiquill-saved` and `proofora-saved` as legacy migration keys, with isolated sample and chain/address namespaces.
- Keep `VITE_CONTRACT_ADDRESS`, `VITE_CHAIN_ID`, `VITE_RPC_URL`, `VITE_EXPLORER_URL`, `ROBINHOOD_RPC_URL`, `ROBINHOOD_CHAIN_ID`, `DEPLOYER_PRIVATE_KEY` and all existing configuration interfaces.
- Keep the recorded deployment at `0x58484BB53186904d65C23fb5c58C3BF191b3cD62`, chain ID 46630, RPC/explorer URLs and current `contracts/deployment.json`. Local validation does not prove that a recorded address runs current source.
- The current naming rationale is [REBRAND-NAMING-CITEWARD.md](REBRAND-NAMING-CITEWARD.md). Current browser evidence and project checks are linked in [RESKIN-VALIDATION.md](RESKIN-VALIDATION.md).

The Citeward choice is a local product identity decision. No domain or handle availability checks, trademark clearance, registration, publication, deployment or asset migration are implied. Current launch materials use no unverified domain or social account.
