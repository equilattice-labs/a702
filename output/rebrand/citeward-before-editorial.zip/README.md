# Citeward

**Move questions forward.**

Citeward 是面向 Robinhood Chain testnet 的开放研究任务平台：发布研究问题、资助任务、提交公开证据、由创建者审核，再领取分配的测试网 ETH。

网站采用 Citeward 钴蓝、纸白与柠檬黄品牌色：深墨色紧凑首屏连接研究工作台，桌面左侧主题导航与右侧任务列表便于筛选和比较，移动端使用单列布局。任务详情、两步创建、收藏与奖励流程延续现有业务规则，网站不提供 Twitter / X 链接。

## 项目入口

- [网站与运行说明](website/README.md)：Vue 3 + Vite，响应式研究任务工作台。
- [品牌规范](BRANDING.md)：名称、标识、色彩、文案及兼容保留规则。
- [品牌命名说明](REBRAND-NAMING-CITEWARD.md)：Citeward 的含义、定位与使用边界。
- [商业计划](business-plan.md)。
- [品牌传播物料](twitter/README.md)：Citeward 最终头像、横幅、分享卡、任务卡、视频与发布草稿。
- [合约](contracts/README.md)及[验证记录](contracts/REBRAND-VALIDATION.md)。
- [改版验收报告](RESKIN-VALIDATION.md)：功能、浏览器、无障碍、响应式和产物核对。

## 本地运行

在 `website/` 目录运行：

```powershell
npm install
npm run dev
npm run check:logic
npm run build:all
npm run check:site
```

`website/a702/` 是同步分发副本。请修改主站源文件，通过 `npm run sync:mirror` 同步；环境文件各自独立。

## 预览

[桌面页面](website/output/playwright/citeward-1440.png) · [移动页面](website/output/playwright/citeward-390.png) · [Citeward 视频](twitter/citeward-loop.mp4)

本项目使用测试网 ETH，没有平台代币。既有合约 ABI、部署地址和网络接口保持兼容。域名及社交账号尚未配置。当前成果为 Citeward 本地源码、构建产物、素材和验证记录，未执行外部发布或部署。
