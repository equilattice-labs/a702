﻿# Citeward social kit

Citeward is an open research mission platform: creators fund questions, contributors share evidence, and selected contributors withdraw native testnet ETH rewards.

**Tagline:** Move questions forward.

The identity uses cobalt (`#2449E8`), ink (`#17203A`), paper (`#F7F8FC`), and citron (`#E7F588`), with open brackets, an upper-right arrow and bold sans serif typography. The artwork uses native vector geometry and local typography.

These are local Citeward publication materials. The website contains no Twitter / X links.

## Brand and deployment boundaries

- Display name: **Citeward**. File slug: `citeward`.
- Network: **Robinhood Chain Testnet**. Bounty currency: **ETH** (testnet only).
- No new token or token ticker is introduced.
- Public domain and social handle: **not configured or verified**. No ownership or availability claim is made.
- Campaign illustrations explain a workflow; they do not show live missions, balances, activity, or guaranteed rewards.
- Research material is not financial advice.

## Assets

| File | Size / use |
| --- | --- |
| `citeward-mark.svg` | Scalable open brackets and advance arrow; suitable for the site and favicon |
| `logo.png` | 800 x 800 profile image |
| `banner.png` | 1500 x 500 X header |
| `citeward-social.png` | 1200 x 630 link preview |
| `mission-card.png` | 1200 x 675 mission workflow card |
| `primitives.png` | 1200 x 675 fund / contribute / review card |
| `citeward-loop.mp4` | 1280 x 720 H.264 video, 24 fps, 10 seconds |

## Regeneration

Install Pillow and make `ffmpeg` available on PATH. From the repository root:

```powershell
python twitter/generate_assets.py --encode
```

Without `--encode`, the script regenerates the SVG and five PNG assets. With `--encode`, it streams 240 frames directly to ffmpeg and writes the final video without keeping intermediate frame files. Add `--sync-public` only when the website mark and social preview should also be refreshed; then run the website mirror sync command.

The font resolver uses Windows Arial when available and DejaVu Sans on Linux, with regular and bold weights. Text bounds are checked during every render. Different fonts can change text widths, so visually review exports after changing the font configuration.

The generator is deterministic and uses local drawing primitives. No network, account, wallet, domain, or deployment operations are performed.

## Publication copy

`content.txt` includes the bio and three-post thread. `drafts.txt` contains two standalone alternatives. Media paths are local files; no post has been published by this kit.

Before publication, confirm the configured deployment, selected network, and any links or account handles added by the publisher. All ETH references must remain clearly identified as testnet ETH.
