"""Build Citeward's social kit from local vector geometry and typography.

Run: python twitter/generate_assets.py --encode
Requires Pillow and ffmpeg. No network, account, or deployment access is used.
Use --sync-public to also copy the mark and social preview to website/public.
"""
from pathlib import Path
import argparse
import math
import shutil
import subprocess
from PIL import Image, ImageDraw, ImageFont

OUT = Path(__file__).resolve().parent
PUBLIC = OUT.parent / 'website' / 'public'
COBALT, INK, PAPER, CITRON = '#2449E8', '#17203A', '#F7F8FC', '#E7F588'
MUTED, LINE, WHITE = '#626B80', '#D8DDEB', '#FFFFFF'
FPS, FRAMES = 24, 240
FONT_PATHS = {
    'body': ['C:/Windows/Fonts/arial.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'],
    'bold': ['C:/Windows/Fonts/arialbd.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'],
}
FONT_CACHE = {}


def font(size, family='body'):
    key = size, family
    if key not in FONT_CACHE:
        path = next((p for p in FONT_PATHS[family] if Path(p).exists()), None)
        if not path:
            raise RuntimeError(f'No supported {family} font found; edit FONT_PATHS.')
        FONT_CACHE[key] = ImageFont.truetype(path, size)
    return FONT_CACHE[key]


def canvas(w, h, color=PAPER):
    im = Image.new('RGB', (w, h), color)
    return im, ImageDraw.Draw(im)


def text(d, value, xy, size=24, color=INK, family='body', anchor='lt'):
    bounds = d.textbbox(xy, value, font=font(size, family), anchor=anchor)
    w, h = d._image.size
    if bounds[0] < 0 or bounds[1] < 0 or bounds[2] > w or bounds[3] > h:
        raise ValueError(f'Text outside canvas: {value!r}, bounds={bounds}, canvas={w}x{h}')
    d.text(xy, value, font=font(size, family), fill=color, anchor=anchor)


def lines(d, values, xy, size=24, color=INK, family='body', leading=None):
    for i, value in enumerate(values):
        text(d, value, (xy[0], xy[1] + i * (leading or round(size * 1.28))), size, color, family)


def label(d, value, xy, color=MUTED, size=14):
    text(d, value, xy, size, color, 'bold')


def arrow(d, xy, size, color=COBALT, width=None):
    x, y = xy
    width = width or max(3, round(size * .12))
    # Square ends echo a source citation's brackets.
    d.line((x, y + size, x + size, y), fill=color, width=width)
    d.line((x + size * .24, y, x + size, y, x + size, y + size * .76), fill=color, width=width, joint='curve')


def geometry(d, origin, scale, bracket=WHITE, pointer=CITRON):
    x, y = origin
    def polygon(points, color):
        d.polygon([(x + a * scale, y + b * scale) for a, b in points], fill=color)
    polygon([(26,15),(14,15),(14,49),(26,49),(26,43),(20,43),(20,21),(26,21)], bracket)
    polygon([(32,18),(50,18),(50,36),(44,36),(44,28),(31,41),(27,37),(40,24),(32,24)], pointer)


def symbol(size=128, background=COBALT, bracket=WHITE, pointer=CITRON):
    # Supersampled geometry is shared with citeward-mark.svg.
    factor = 4
    im = Image.new('RGBA', (size * factor, size * factor), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    s = size * factor / 64
    if background:
        d.rounded_rectangle((0, 0, size * factor - 1, size * factor - 1), radius=12*s, fill=background)
    geometry(d, (0, 0), s, bracket, pointer)
    return im.resize((size, size), Image.Resampling.LANCZOS)


def brand(im, xy=(56, 44), size=42, color=INK, tile=True):
    mark = symbol(size, COBALT if tile else None)
    im.paste(mark, xy, mark)
    text(ImageDraw.Draw(im), 'Citeward', (xy[0] + size + 12, xy[1] + size / 2), round(size*.72), color, 'bold', 'lm')


def footer(d, y, width, left='OPEN RESEARCH / SHARED EVIDENCE', color=MUTED):
    d.line((54, y, width-54, y), fill=LINE, width=1)
    label(d, left, (55, y+22), color, 12)
    text(d, 'ROBINHOOD CHAIN TESTNET', (width-55, y+22), 12, color, 'bold', 'rt')


def write_vector():
    (OUT / 'citeward-mark.svg').write_text('''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" role="img" aria-labelledby="title desc">
  <title id="title">Citeward</title>
  <desc id="desc">A white citation bracket and citron arrow pointing forward on a cobalt square.</desc>
  <rect width="64" height="64" rx="12" fill="#2449E8"/>
  <path d="M26 15H14V49H26V43H20V21H26Z" fill="#FFFFFF"/>
  <path d="M32 18H50V36H44V28L31 41L27 37L40 24H32Z" fill="#E7F588"/>
</svg>
''', encoding='utf-8')


def logo():
    im, d = canvas(800, 800, COBALT)
    geometry(d, (0, 0), 12.5)
    im.save(OUT / 'logo.png')


def banner():
    im, d = canvas(1500, 500, COBALT)
    brand(im, (56, 35), 49, WHITE, tile=False)
    text(d, 'OPEN RESEARCH, IN MOTION.', (1440, 58), 14, WHITE, 'bold', 'rm')
    lines(d, ['Move questions', 'forward.'], (59, 139), 88, WHITE, 'bold', leading=101)
    geometry(d, (1085, 72), 5.65)
    d.rectangle((0, 409, 1500, 500), fill=CITRON)
    label(d, 'BRIEF', (61, 448), INK, 17)
    text(d, '/', (143, 448), 17, INK)
    label(d, 'EVIDENCE', (171, 448), INK, 17)
    text(d, '/', (289, 448), 17, INK)
    label(d, 'REVIEW', (316, 448), INK, 17)
    text(d, '/', (416, 448), 17, INK)
    label(d, 'REWARD', (445, 448), INK, 17)
    text(d, 'Robinhood Chain Testnet / Native testnet ETH', (1440, 456), 17, INK, anchor='rm')
    im.save(OUT / 'banner.png')


def social():
    im, d = canvas(1200, 630)
    brand(im, (53, 40), 45)
    text(d, 'THE NEXT QUESTION STARTS HERE', (1146, 63), 12, MUTED, 'bold', 'rm')
    lines(d, ['Move questions', 'forward.'], (53, 162), 82, INK, 'bold', leading=97)
    d.rectangle((774, 274, 1146, 471), fill=COBALT)
    text(d, '[ A better answer ]', (800, 296), 21, WHITE, 'bold')
    lines(d, ['Built with sources.', 'Open to contributors.'], (800, 353), 22, WHITE, leading=32)
    arrow(d, (1086, 413), 30, CITRON, 5)
    lines(d, ['Fund a brief. Contribute evidence.', 'Give useful research a way forward.'], (58, 404), 24, MUTED, leading=36)
    footer(d, 550, 1200)
    im.save(OUT / 'citeward-social.png')


def mission():
    im, d = canvas(1200, 675)
    brand(im, (53, 36), 43)
    text(d, 'A MISSION, FROM QUESTION TO REWARD', (1146, 58), 12, MUTED, 'bold', 'rm')
    d.rectangle((53, 118, 1147, 278), fill=COBALT)
    label(d, 'A RESEARCH MISSION', (77, 140), CITRON, 13)
    text(d, 'Bring a question. Build on evidence.', (77, 184), 43, WHITE, 'bold')
    steps = [
        ('01', 'Read the brief', ['Start with the question,', 'scope and testnet bounty.']),
        ('02', 'Add evidence', ['Submit sources with', 'your reasoning and context.']),
        ('03', 'Creator review', ['The creator reviews and', 'selects contributions.']),
        ('04', 'Claim a reward', ['Selected contributors', 'withdraw testnet ETH.']),
    ]
    for i, (num, title, body) in enumerate(steps):
        x = 54 + i * 280
        text(d, num, (x, 314), 63, COBALT, 'bold')
        if i < 3:
            d.line((x+111, 345, x+236, 345), fill=LINE, width=2)
            arrow(d, (x+225, 333), 17, MUTED, 3)
        text(d, title, (x, 403), 24, INK, 'bold')
        lines(d, body, (x, 449), 18, MUTED, leading=29)
    d.rectangle((54, 541, 1147, 582), fill=CITRON)
    text(d, 'Useful evidence moves the work forward.', (78, 553), 17, INK, 'bold')
    footer(d, 607, 1200, 'ILLUSTRATIVE WORKFLOW / TESTNET ONLY')
    im.save(OUT / 'mission-card.png')


def primitives():
    im, d = canvas(1200, 675, INK)
    brand(im, (53, 37), 43, WHITE)
    text(d, 'THE CITEWARD TOOLKIT', (1146, 58), 12, CITRON, 'bold', 'rm')
    text(d, 'Make research move.', (54, 134), 64, WHITE, 'bold')
    items = [
        ('01', 'A focused brief', ['Define a question and scope.', 'Fund it with native', 'testnet ETH.']),
        ('02', 'Evidence + context', ['Link your sources.', 'Explain what they show.', 'Make your reasoning clear.']),
        ('03', 'Review + reward', ['The creator selects work.', 'Selected contributors', 'withdraw their rewards.']),
    ]
    for i, (num, title, body) in enumerate(items):
        x = 54 + i * 371
        d.rectangle((x, 248, x+351, 537), fill=COBALT if i == 1 else PAPER)
        fg, sub = (WHITE, '#E3E8FF') if i == 1 else (INK, MUTED)
        label(d, '[' + num + ']', (x+25, 275), CITRON if i == 1 else COBALT, 16)
        arrow(d, (x+295, 275), 23, CITRON if i == 1 else COBALT, 4)
        text(d, title, (x+25, 335), 25, fg, 'bold')
        lines(d, body, (x+25, 399), 19, sub, leading=30)
    text(d, 'Move questions forward.', (54, 601), 24, WHITE, 'bold')
    text(d, 'ROBINHOOD CHAIN TESTNET / NO PLATFORM TOKEN', (1146, 615), 12, CITRON, 'bold', 'rm')
    im.save(OUT / 'primitives.png')


STAGES = [
    ('01', 'Fund a question.', 'Give research a focused place to begin.', 'RESEARCH BRIEF', ['A clear question', 'A defined scope', 'A native testnet ETH bounty'], 'CREATOR'),
    ('02', 'Build an answer.', 'Put sources and context behind your reasoning.', 'CONTRIBUTION', ['Source-backed evidence', 'A clear explanation', 'Context others can follow'], 'CONTRIBUTOR'),
    ('03', 'Review the work.', 'The creator selects useful contributions.', 'CREATOR REVIEW', ['Read the reasoning', 'Examine the sources', 'Select contributions'], 'CREATOR'),
    ('04', 'Claim a reward.', 'Selected contributors withdraw testnet ETH.', 'WITHDRAWAL', ['Contribution selected', 'Reward made available', 'Contributor withdraws'], 'CONTRIBUTOR'),
]


def video_frame(index):
    stage, phase = min(index // 60, 3), (index % 60) / 59
    num, title, subtitle, card_title, body, role = STAGES[stage]
    im, d = canvas(1280, 720)
    brand(im, (47, 32), 44)
    text(d, 'MOVE QUESTIONS FORWARD.', (1232, 54), 13, MUTED, 'bold', 'rm')
    d.rectangle((0, 108, 443, 622), fill=COBALT)
    label(d, 'THE MISSION WORKFLOW', (47, 139), CITRON, 13)
    text(d, num, (43, 181), 147, WHITE, 'bold')
    geometry(d, (236, 227 + round(math.sin(phase * math.pi) * -7)), 2.52)
    lines(d, title.split(' ', 1), (47, 394), 45, WHITE, 'bold', leading=57)
    text(d, role, (47, 570), 13, CITRON, 'bold')
    text(d, card_title, (492, 145), 15, COBALT, 'bold')
    text(d, subtitle, (491, 191), 24, INK, 'bold')
    for j, value in enumerate(body):
        y = 281 + j*94
        active = phase >= j/4
        d.rectangle((490, y-14, 1231, y+60), fill=WHITE if active else PAPER, outline=LINE)
        d.rectangle((511, y+9, 539, y+37), fill=COBALT if active else LINE)
        if active:
            d.line((518, y+23, 524, y+29, 533, y+16), fill=WHITE, width=3)
        text(d, value, (560, y+12), 23, INK if active else MUTED)
    for j, value in enumerate(['Fund', 'Contribute', 'Review', 'Withdraw']):
        x = 48 + j*310
        d.rectangle((x, 652, x+286, 656), fill=LINE)
        if j <= stage:
            d.rectangle((x, 652, x+round(286*(phase if j == stage else 1)), 656), fill=COBALT)
        text(d, value, (x, 673), 16, COBALT if j == stage else MUTED, 'bold')
    text(d, 'ROBINHOOD CHAIN TESTNET / ILLUSTRATIVE WORKFLOW', (1228, 585), 11, MUTED, 'bold', 'rt')
    return im


def encode():
    ffmpeg = shutil.which('ffmpeg')
    if not ffmpeg:
        raise RuntimeError('ffmpeg is required to encode citeward-loop.mp4')
    command = [ffmpeg, '-hide_banner', '-loglevel', 'error', '-y',
               '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', '1280x720', '-r', str(FPS),
               '-i', 'pipe:0', '-frames:v', str(FRAMES),
               '-c:v', 'libx264', '-crf', '18', '-pix_fmt', 'yuv420p', '-movflags', '+faststart',
               str(OUT / 'citeward-loop.mp4')]
    with subprocess.Popen(command, stdin=subprocess.PIPE) as process:
        try:
            for index in range(FRAMES):
                process.stdin.write(video_frame(index).tobytes())
        finally:
            process.stdin.close()
        if process.wait() != 0:
            raise subprocess.CalledProcessError(process.returncode, command)


def sync_public():
    PUBLIC.mkdir(exist_ok=True)
    for filename in ['citeward-mark.svg', 'citeward-social.png']:
        shutil.copyfile(OUT / filename, PUBLIC / filename)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--encode', action='store_true', help='also encode the 10-second H.264 video')
    parser.add_argument('--sync-public', action='store_true', help='also copy the mark and preview into website/public')
    args = parser.parse_args()
    write_vector()
    logo()
    banner()
    social()
    mission()
    primitives()
    if args.encode:
        encode()
    if args.sync_public:
        sync_public()
    print('Citeward: 5 PNG assets and SVG mark' + (', plus MP4 regenerated without frame files.' if args.encode else ' regenerated.'))
