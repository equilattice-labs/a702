# Siftlane identity replacement map

2026-09-16. The user explicitly requires a new brand and no Twitter/X links anywhere on the website. This map defines the local product identity before editing.

| Identity | Previous | New |
| --- | --- | --- |
| Display / uppercase | Citeward / CITEWARD | Siftlane / SIFTLANE |
| Slug / website package | citeward | siftlane |
| Contract package | citeward-chain-contracts | siftlane-chain-contracts |
| Tagline | Move questions forward. | Make the evidence clear. |
| Saved missions | citeward-saved | siftlane-saved; migrate existing bookmarks |
| Mark | Citation bracket with upper-right arrow | Three staggered lanes with a selected signal dot |
| Primary / hover | Terracotta | Deep jade #164E48 / #103E39 |
| Ink / muted / canvas | Warm journal palette | #182E2C / #586963 / #F5F7F3 |
| Accent / surface | Olive/sage | Signal lime #EAF3A7 / pale jade #E4EFEB |
| Typography | Serif headings | Local DM Sans display and interface, monospace annotations |
| Token / ticker | None | None; rewards remain native testnet ETH |
| Domain / handle | Unconfigured | Unconfigured; no availability, ownership or clearance claim |

Preserve `EvidaraEscrow`, ABI/function/event identity, `Evidara:` errors, deployment history, chain ID 46630, RPC/explorer addresses and environment interfaces. Keep `citeward-saved`, `civiquill-saved`, and `proofora-saved` solely as legacy migration keys. Do not change previously deployed bytecode or recorded addresses.

Update display copy, metadata, source identifiers belonging to the local brand, resource filenames, package roots, launch assets, documentation and reproducible validation. Regenerate assets and production builds. Archive superseded evidence rather than claim it verifies Siftlane. Preserve snapshots under website/output/rebrand.

Siftlane describes sifting evidence into a clear research path. The mark and visual system should express filtering and a selected source, not the previous citation bracket. There are no Twitter/X destinations in website navigation or public metadata. Dynamically rendered external links must also respect the website's no-Twitter/X requirement.
