# Siftlane brand guide

**Make the evidence clear.**

Siftlane is an open research mission platform. **Sift** expresses examining sources and finding useful evidence; **lane** gives that work a clear path from question to review. Pronounce it **SIFT-layn**. A research mission connects a funded brief, public evidence, creator review and a visible outcome.

## Canonical identity

| Key | Current value |
| --- | --- |
| Display name | Siftlane |
| Uppercase / slug | SIFTLANE / siftlane |
| Product description | An open research mission platform. |
| Tagline | Make the evidence clear. |
| Website package | siftlane |
| Contract package | siftlane-chain-contracts |
| Platform token / ticker | None. SIFTLANE is a brand spelling, not a token symbol. |
| Native currency | Testnet ETH |
| Network | Robinhood Chain testnet, chain ID 46630 |
| Domain / social account | Unconfigured; no availability or ownership claim |
| Primary color | Deep jade `#164E48`; hover `#103E39` |
| Text colors | Ink `#182E2C`; muted `#586963` |
| Canvas / surface | `#F5F7F3` / white `#FFFFFF` |
| Supporting colors | Pale jade `#E4EFEB`; signal lime `#EAF3A7` |
| Website typography | Local DM Sans, registered as `Siftlane Sans`, for bold display headings and interface text; monospace annotations |
| Social typography | Arial regular/bold and Consolas annotations on Windows; DejaVu Sans and Sans Mono fallbacks on Linux |
| Mark | Three staggered white filtering lanes and a lime selected signal dot on deep jade |

## Voice and interface

Use plain, specific actions: **Explore missions**, **Create a mission**, **Submit evidence**, **Review contributions**, **Claim rewards**. Explain what the user can do next and show the mission's deadline, funding and review status where a decision is made. Use bold sans serif headings, clear research summaries, deep jade actions and pale green panels. Lime identifies a selected signal or a deliberate point of emphasis. Monospace annotations name the stage or category without competing with the research itself.

The visual metaphor is evidence moving through a series of filtering lanes. The three channels and selected dot are original Siftlane geometry. Campaign artwork combines large plain statements, offset evidence rows and an explicit creator-review step. SVG, avatar, banner, preview cards and the workflow video are generated from `twitter/generate_assets.py`; rendered text is checked against canvas bounds.

The website must not include Twitter / X links, including links introduced through public mission or evidence data. It also contains no Twitter-specific metadata. Locally maintained campaign assets are separate publication materials; they do not create website navigation or footer destinations.

Clearly distinguish sample missions, live testnet data, wallet requests and confirmed transactions. The mission creator reviews evidence and allocates escrow before the deadline; rewards are not automatic. Siftlane does not issue a token or promise financial returns.

## Technical compatibility

- Keep `EvidaraEscrow`, its source filename, ABI types, function/event names and `Evidara:` revert prefix. These are technical compatibility details.
- Current saved missions use `siftlane-saved`. Preserve `citeward-saved`, `civiquill-saved` and `proofora-saved` as legacy migration keys, with isolated sample and chain/address namespaces.
- Keep `VITE_CONTRACT_ADDRESS`, `VITE_CHAIN_ID`, `VITE_RPC_URL`, `VITE_EXPLORER_URL`, `ROBINHOOD_RPC_URL`, `ROBINHOOD_CHAIN_ID`, `DEPLOYER_PRIVATE_KEY` and all existing configuration interfaces.
- Keep the recorded deployment at `0x58484BB53186904d65C23fb5c58C3BF191b3cD62`, chain ID 46630, RPC/explorer URLs and current `contracts/deployment.json`. Local validation does not prove that a recorded address runs current source.
- The naming rationale is [REBRAND-NAMING-SIFTLANE.md](REBRAND-NAMING-SIFTLANE.md). Current browser evidence and project checks are linked in [RESKIN-VALIDATION.md](RESKIN-VALIDATION.md).

The Siftlane choice is a local product identity decision. No domain or handle availability checks, trademark clearance, registration, publication, deployment or asset migration are implied. Current launch materials use no unverified domain or social account. Superseded publication assets are retained only in the explicit archive under `twitter/archive/` and are not part of the active brand kit.
