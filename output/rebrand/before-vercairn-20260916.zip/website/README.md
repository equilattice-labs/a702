﻿# Siftlane website

Make the evidence clear.

A Vue 3 + Vite research workspace for Robinhood Chain testnet, organized around filtering sources and making useful evidence clear. Native testnet ETH is used for escrow rewards; Siftlane has no platform token.

## Run and verify

```powershell
npm install
npm run dev -- --host 127.0.0.1 --port 5173
npm run check:logic
npm run build:all
npm run check:site
npx playwright install chromium
npm run preview -- --host 127.0.0.1 --port 42702 --strictPort
# In another terminal, while preview is running:
npm run check:ui
npm run check:experience
```

`npm run build:all` builds this site, synchronizes its public source into `a702/`, then builds that entry point. Both support deployment at a subpath through relative Vite assets. `a702/` is a distribution mirror; edit the parent source and run `npm run sync:mirror` to keep it consistent. Environment files are never copied by that script.

The local production preview is available at `http://127.0.0.1:42702/` while the preview command is running.

## Configuration

Copy `.env.example` to `.env` and set `VITE_CONTRACT_ADDRESS` to the verified deployed address. The existing public configuration interface remains `VITE_CONTRACT_ADDRESS`, `VITE_CHAIN_ID`, `VITE_RPC_URL`, and `VITE_EXPLORER_URL`. The default chain ID is 46630; verify current Robinhood Chain testnet network documentation before sending transactions.

Without a valid address the app shows clearly labeled sample missions. Once configured, only contract data is shown; RPC failures provide a retry state. No wallet permission is requested until the user connects or begins a transaction. The ABI remains `src/EvidaraEscrow.abi.json` to preserve the deployed contract identity.

## Interface and behavior

- A sticky top navigation opens Explore, Saved, My missions and the contributor guide. On narrow screens, a menu below the header provides navigation, rewards and mission creation.
- A sans-serif introduction pairs with a new signal-filter illustration: staggered lanes and a selected signal dot express the path from sources to evidence. The featured entry uses the loaded collection independently of list search, topic filters and saved views. Loading, retry and empty-collection states remain explicit.
- The research collection uses two columns of mission cards on desktop, horizontal topic filters and a single column on narrow screens. Each card shows its brief, reward and next action. Search and all four sort choices remain available; Clear search restores focus to the input, while applied-filter chips remove the topic or query individually or reset both. Saved is local to the device, and My missions shows missions created by the connected wallet.
- The mission drawer has semantic Brief, Contribute and Review tabs linked to their panels. Left / Right arrows cycle through the tabs; Home / End select the first or last tab. Public brief and evidence links retain their URL safety checks and exclude Twitter/X destinations, including dynamic mission content.
- Two-step mission creation with validation and a downloadable Markdown draft. The draft is not uploaded automatically: publish it and supply its URL. In-memory draft edits remain until the page is left or creation succeeds.
- Funding, evidence submission, creator approval, deadline refunds, and reward claiming use the original contract methods. Approval is only possible before the deadline. Refunded unallocated funds become the creator's claimable balance; additional funders have no individual refund rights.
- Keyboard focus stays inside native dialogs; Escape and focus restoration work. The mobile navigation supports keyboard closing and focus containment. Amount inputs preserve 18-decimal strings.
- Bookmarks migrate from `citeward-saved`, `civiquill-saved` or `proofora-saved` into `siftlane-saved`, with separate namespaces for sample and chain/address missions. Invalid or unavailable local storage does not crash the app.
- The page explains the ask, investigate and review workflow, provides a mission-creation call to action, and answers questions about creator review, testnet rewards and unused funds.

## Source and visual identity

`src/composables/useMissions.js` owns wallet, contract, validation and mission state. `src/App.vue` coordinates navigation, filters, forms and dialogs. `src/components/ResearchCover.vue` renders the signal-filter cover, local HTML/CSS illustration and featured entry; `src/components/MissionCard.vue` renders each mission and emits open/save actions. These presentation components use the existing mission data contract. `src/utils/format.js` shares amount display formatting between mission cards and rewards; transaction input values retain their original precision.

`src/style.css` imports `src/styles/workspace.css` for shared tokens, typography, page layout, controls and responsive behavior, and `src/styles/dialogs.css` for the detail drawer and form dialogs. The DM Sans font, SVG mark and Open Graph preview are served locally; the font license is included in `public/fonts/`.

The design uses deep jade `#164E48` with hover `#103E39`, chalk `#F5F7F3`, ink `#182E2C`, muted text `#586963`, signal lime `#EAF3A7` and pale jade `#E4EFEB`. Local DM Sans, registered as `Siftlane Sans`, serves headings and interface text, with monospace annotations. Three staggered lanes and a selected signal dot form the mark. The same filtering motif connects the hero, local media and mission controls.

The website contains no Twitter/X links or platform-specific sharing metadata. No domain or social account is claimed. After a verified production origin exists, resolve Open Graph image paths to absolute public URLs and set a canonical URL.

## Verification evidence

Browser captures and reports use the `siftlane-` prefix in `output/playwright/`. See [the current validation report](../RESKIN-VALIDATION.md) for the verified revision, results and scope. `scripts/check-mission-logic.mjs` uses in-memory configuration and wallet/contract mocks, never real credentials or chain transactions. `scripts/siftlane-rpc-fixture.cjs` supports isolated browser verification. `check:site` verifies the brand, prohibited outbound links, local resources and exact distribution mirror. Contract verification is recorded in `../contracts/REBRAND-VALIDATION.md`.
