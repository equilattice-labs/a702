<script setup>
import UiIcon from "./UiIcon.vue";
defineProps({
  mission: { type: Object, default: null },
  loading: Boolean,
  error: { type: String, default: "" },
});
defineEmits(["explore", "create", "open", "retry"]);
</script>

<template>
  <section class="hero" aria-labelledby="hero-title">
    <div class="hero-copy">
      <div class="eyebrow">
        <span class="label-dash"></span>OPEN QUESTIONS. TRACEABLE ANSWERS.
      </div>
      <h1 id="hero-title">Make the<br /><em>evidence clear.</em></h1>
      <p>
        Good research starts with a focused question. Fund a mission, connect
        the sources, and turn shared curiosity into evidence anyone can follow.
      </p>
      <div class="hero-actions">
        <button class="button primary" @click="$emit('explore')">
          Explore missions<UiIcon name="arrow" :size="18" />
        </button>
        <button class="text-button" @click="$emit('create')">
          Create a mission<UiIcon name="plus" :size="17" />
        </button>
      </div>
      <div class="hero-caption">
        <span class="caption-rule"></span>A workspace for people who look
        closer.
      </div>
    </div>
    <div class="signal-panel">
      <div class="signal-heading">
        <span class="signal-wordmark">SIFTLANE</span
        ><span>THE RESEARCH PATH</span>
      </div>
      <div class="signal-art" aria-hidden="true">
        <div class="signal-grid"></div>
        <div class="signal-track track-one">
          <span class="signal-node"></span><span class="signal-path"></span
          ><span class="signal-caption">01 / ASK A QUESTION</span>
        </div>
        <div class="signal-track track-two">
          <span class="signal-node"></span><span class="signal-path"></span
          ><span class="signal-caption">02 / CONNECT THE SOURCES</span>
        </div>
        <div class="signal-track track-three">
          <span class="signal-node"></span><span class="signal-path"></span
          ><span class="signal-caption">03 / MAKE IT VERIFIABLE</span>
        </div>
        <div class="signal-output">
          <UiIcon name="check" :size="20" /><span>CLEARER EVIDENCE</span>
        </div>
        <span class="signal-coordinate"
          >FROM A QUESTION TO A SHARED FINDING</span
        >
      </div>
      <div v-if="loading" class="featured-brief featured-status" role="status">
        <span class="spinner"></span>Finding the next question…
      </div>
      <div v-else-if="error" class="featured-brief featured-status">
        <p>Research is a little out of reach.</p>
        <button class="text-button" @click="$emit('retry')">
          Retry loading<UiIcon name="refresh" :size="16" />
        </button>
      </div>
      <button
        v-else-if="mission"
        class="featured-brief"
        aria-label="Open featured mission"
        @click="$emit('open', mission)"
      >
        <span class="featured-label">{{
          mission.sample
            ? "EXPLORE A SAMPLE MISSION"
            : "A QUESTION TO START WITH"
        }}</span>
        <span class="featured-title">{{ mission.title }}</span
        ><UiIcon name="arrow" :size="21" />
      </button>
      <div v-else class="featured-brief featured-status">
        <p>The next question could be yours.</p>
        <button class="text-button" @click="$emit('create')">
          Write the first brief<UiIcon name="plus" :size="16" />
        </button>
      </div>
    </div>
  </section>
</template>
