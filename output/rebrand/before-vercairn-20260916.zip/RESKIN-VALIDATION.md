# Siftlane 品牌与体验重构验收

2026-09-16（Asia/Shanghai）。按 `rebrand` 与 `reskin` skill 完成全新品牌和整站体验重构，并验证 website 不含 Twitter / X 链接。

## 全新品牌交付

当前品牌为 **Siftlane / siftlane / SIFTLANE**，标语 **Make the evidence clear.**，寓意筛选证据、理清研究路径。旧展示品牌已替换；准确映射见 [REBRAND-MAP.md](REBRAND-MAP.md)，新规范见 [BRANDING.md](BRANDING.md) 与 [命名说明](REBRAND-NAMING-SIFTLANE.md)。

- 新标识为三条错位筛选通道与选中信号圆点；网站、favicon、分享图、头像、横幅、任务流程图、工具图和视频均使用新标识。
- 深玉绿 `#164E48`、青柠黄 `#EAF3A7`、浅灰白 `#F5F7F3`，本地 DM Sans 粗体标题与等宽注释组成新的视觉体系。
- 网站、配置、包名和 lock 根身份、下载草稿、品牌及商业文档、传播文案均已更新。合约包为 `siftlane-chain-contracts`，主站与镜像包为 `siftlane`。
- 原始 PNG / SVG / MP4 和旧验证记录已归档，不作为本轮成果；当前素材由 `twitter/generate_assets.py` 本地再生成。当前 5 张 PNG 可解码、SVG XML 有效；视频 H.264、1280×720、24 fps、10 秒。网站与传播原件哈希一致。

## UI 和用户体验

- 深色顶部导航、无衬线首屏与研究路径图、青柠色推荐任务入口，进入带独立边界的研究工作区。桌面双列任务卡、横向主题筛选；移动端单列并保留全部操作。
- 首屏推荐打开已读取集合第一项任务，独立于搜索、排序和收藏筛选。加载、错误和真实空集合有对应状态；失败或空集合不会留下过期推荐链接。
- 搜索可单独清除并恢复焦点，保留主题；筛选关键词与主题可逐项移除或共同重置。四种排序、收藏刷新保留和个人创建任务视图通过回归。
- 详情采用有正确关联的 `tablist` / `tab` / `tabpanel`，支持方向键、Home / End 和唯一 Tab 停靠点；移动菜单焦点约束、Escape 与焦点返回保持有效。
- 两步创建支持校验、纠正、预览、编辑、保留草稿与下载。资金数值保留原始十进制输入，支持精确 1 wei。资助、提交证据、审批、退款和奖励页面采用统一样式。
- `ResearchCover.vue`、`MissionCard.vue` 负责展示；`useMissions.js` 保持业务边界；`utils/format.js` 共用金额展示。`style.css` 引入 `styles/workspace.css` 与 `styles/dialogs.css`，原期刊样式文件已替换。

## 无 Twitter / X 链接

静态与动态两层检查均覆盖主站及 `a702`：

1. `check:site` 扫描 src、public、index 和真实 dist 内容及资源名，禁止 Twitter / X / t.co 外链与 Twitter 专用 metadata。
2. `safeExternalUrl` 拒绝 `twitter.com`、`x.com`、`t.co` 及其子域、大小写、尾点、端口和 URL 标准化变体。Brief、evidence 与 explorer 的外部 href 共用这一入口。
3. 逻辑测试验证禁链边界，同时保留合法相似域和 IPFS 来源。
4. 浏览器 fixture 实际注入 Twitter brief 和 X evidence，确认页面不生成这些链接，合法 IPFS 证据仍可访问。运行页面也检查全部 href 与 metadata。

旧 URL 如已存储在历史任务中仍保留原始数据；本次改变的是网站链接输出，不修改链上数据。独立传播文案目录不构成网站社交入口。

## 保留的业务契约

六类合约操作保持兼容：发布、资助、提交证据、创建者审批、到期退款、领取奖励。审批在截止前完成；到期未分配余额转入创建者 claimable，再由创建者领取，其他资助者无单独退款权。

新收藏键为 `siftlane-saved`，按最近优先从 `citeward-saved`、`civiquill-saved`、`proofora-saved` 迁移，明确空列表优先，保留 sample 与链 / 地址命名空间隔离。

`EvidaraEscrow`、ABI、函数 / 事件、`Evidara:` revert 前缀、部署记录、链 ID 46630、RPC / explorer 与环境变量接口保留。合约仅更新展示注释；当前 ABI 一致，剥离编译 metadata 后执行字节码与基线相同。报告见 [合约验证](contracts/REBRAND-VALIDATION.md)。

## 本轮验证

| 检查 | 结果 |
| --- | --- |
| `npm run check:logic` | 5 组、189 个断言通过，含六类交易、精度、权限、收藏迁移和禁链边界 |
| `npm run build:all` | 主站、a702 均构建成功，生产 JS / CSS 内容一致 |
| `npm run check:site` | 327 项通过，包含 src / public / dist、动态 URL 守卫、品牌和镜像一致性 |
| 品牌审计 | 107 个公开文本文件、15 个当前发布媒体文件，旧名、旧标语、旧配色及文件名检查后 0 未解决项；保留项逐 token 分类 |
| 本地 Hardhat | 7 个合约测试通过；使用测试专用隔离加载器，不读取部署凭据 |
| `npm run check:ui` | 7 组流程通过：推荐、筛选、排序、收藏、详情、草稿、钱包缺失、指南、奖励、FAQ |
| `npm run check:live` | 8 组隔离 RPC 流程通过：加载、审批、权限、截止状态、危险及社交 URL、重试、空集合、切网奖励 |
| 响应式 | 320 / 390 / 768 / 1024 / 1440 / 1920 px 均无横向溢出，首屏主操作可见 |
| axe | 页面 320 / 390 / 1440、桌面详情、手机创建、创建者审核共 6 个状态，WCAG 2 A/AA、2.1 AA 均 0 违规 |
| `npm run check:experience` | 390×844 触摸模拟：搜索清除保留主题、收藏详情返回、非法 URL 纠正、精确 1 wei 草稿下载通过 |
| 内容适配 | 人工注入长标题、描述、金额、筛选和详情标题无横向溢出；强制色彩与减弱动效通过 |
| 加载稳定性 | 本地字体、标识及首屏资源加载成功；无 JavaScript 异常、失败或外部请求 |

当前 JS **394.51 kB / gzip 141.85 kB**，CSS **42.57 kB / gzip 9.29 kB**。生产文件为 `index-C5r4kA08.js`、`index-Cc2vJMkQ.css`。相较本轮开始的构建，压缩资源增加约 0.18 kB，包含新信号图与禁链逻辑。

1440×1000、新建浏览器上下文、无节流本机预览测得 FCP / LCP **292 ms**，CLS **0**。这不是生产用户指标，未模拟真实设备或弱网。浏览器 fixture 仅使用 `eth_getBalance`、`eth_chainId`、`eth_call`，未签名或发送链上交易。

## 证据

- [本轮开始前基线](website/output/playwright/siftlane-before.png)
- [Siftlane 桌面](website/output/playwright/siftlane-1440.png) / [手机](website/output/playwright/siftlane-390.png) / [完整页面](website/output/playwright/siftlane-full-desktop.png)
- [手机详情](website/output/playwright/siftlane-detail-mobile.png) / [手机创建](website/output/playwright/siftlane-create-mobile.png)
- [创建者审核](website/output/playwright/siftlane-creator-review.png) / [RPC 失败](website/output/playwright/siftlane-rpc-error.png) / [强制色彩](website/output/playwright/siftlane-forced-colors.png)
- [UI / 响应式 / axe 结果](website/output/playwright/siftlane-ui-results.json)
- [隔离 RPC 结果](website/output/playwright/siftlane-live-results.json)
- [触摸与性能结果](website/output/playwright/siftlane-experience.json)
- [品牌残留审计](research/siftlane-brand-residuals.md)
- [改前源码与素材快照](website/output/rebrand/before-siftlane-20260916.zip)

## 本地复核

```powershell
npm --prefix website run check:logic
npm --prefix website run build:all
npm --prefix website run check:site
python research/check-siftlane-brand.py
# 分别启动预览与开发服务：
npm --prefix website run preview -- --host 127.0.0.1 --port 42702 --strictPort
npm --prefix website run dev -- --host 127.0.0.1 --port 5173 --strictPort
# 在另一终端执行：
npm --prefix website run check:ui
npm --prefix website run check:live
npm --prefix website run check:experience
```

预览地址：`http://127.0.0.1:42702/`。合约复核命令与隔离方式见 [contracts/REBRAND-VALIDATION.md](contracts/REBRAND-VALIDATION.md)。本轮没有外部发布、域名注册、链上部署或资金迁移；历史部署地址没有重新核验。域名、社交账号及 canonical 仍未配置。自动无障碍扫描不替代辅助技术实测。
