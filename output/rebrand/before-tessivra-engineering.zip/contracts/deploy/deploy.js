const hre = require("hardhat");
const fs = require("fs");
async function main() {
  const [deployer] = await hre.ethers.getSigners();
  if (!deployer) throw new Error("Set DEPLOYER_PRIVATE_KEY in contracts/.env before deploying");
  console.log(`Deploying Vercairn escrow (EvidaraEscrow) from ${deployer.address}`);
  const Escrow = await hre.ethers.getContractFactory("EvidaraEscrow");
  const escrow = await Escrow.deploy();
  await escrow.waitForDeployment();
  const address = await escrow.getAddress();
  console.log(`Vercairn escrow (EvidaraEscrow): ${address}`);
  fs.writeFileSync("deployment.json", JSON.stringify({ network: hre.network.name, chainId: Number((await hre.ethers.provider.getNetwork()).chainId), address, deployer: deployer.address }, null, 2));
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
