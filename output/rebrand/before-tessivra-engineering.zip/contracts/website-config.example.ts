// Copy to website/src/config/contracts.ts after deployment and replace address.
import abi from '../../../contracts/EvidaraEscrow.abi.json';

export const VERCAIRN_CONTRACT_ADDRESS = '0x0000000000000000000000000000000000000000';
export const VERCAIRN_ABI = abi;
export const ROBINHOOD_TESTNET = {
  chainId: 46630,
  rpcUrl: 'https://rpc.testnet.chain.robinhood.com',
  explorerUrl: 'https://explorer.testnet.chain.robinhood.com',
} as const;
