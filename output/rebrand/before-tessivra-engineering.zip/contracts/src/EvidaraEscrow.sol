// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * Vercairn: an on-chain research mission registry and native ETH bounty
 * escrow. The contract holds only native testnet ETH and has no token,
 * upgrade hook, tax, or investment return promise.
 * The EvidaraEscrow identifier and revert prefixes preserve compatibility.
 */
contract EvidaraEscrow {
    uint256 public constant MAX_TITLE_BYTES = 96;
    uint256 public constant MAX_URI_BYTES = 512;
    uint256 public constant MAX_CATEGORY_BYTES = 32;
    uint256 public constant MAX_MISSION_LIFETIME = 365 days;
    uint256 public constant MAX_PAGE_SIZE = 100;

    struct Mission {
        address creator;
        string title;
        string descriptionURI;
        string category;
        uint64 deadline;
        uint128 totalEscrowed;
        uint128 totalAwarded;
        uint128 totalClaimed;
        uint32 contributionCount;
        bool closed;
    }
    struct Contribution {
        address contributor;
        string evidenceURI;
        uint128 approved;
        uint128 claimed;
        bool approvedByCreator;
    }

    uint256 public missionCount;
    mapping(uint256 => Mission) private _missions;
    mapping(uint256 => Contribution[]) private _contributions;
    mapping(address => uint256) public claimable;
    uint256 public totalEscrowed;
    uint256 public totalAwarded;
    uint256 public totalClaimed;
    uint256 private _locked;

    event MissionCreated(uint256 indexed missionId, address indexed creator, uint256 bounty, uint64 deadline, string title, string category);
    event MissionFunded(uint256 indexed missionId, address indexed funder, uint256 amount);
    event ContributionSubmitted(uint256 indexed missionId, uint256 indexed contributionId, address indexed contributor, string evidenceURI);
    event ContributionApproved(uint256 indexed missionId, uint256 indexed contributionId, address indexed contributor, uint256 amount);
    event RewardsClaimed(address indexed account, uint256 amount);
    event MissionRefunded(uint256 indexed missionId, address indexed creator, uint256 amount);
    event MissionClosed(uint256 indexed missionId);

    modifier validMission(uint256 id) { require(id < missionCount, "Evidara: invalid mission"); _; }
    modifier nonReentrant() {
        require(_locked == 0, "Evidara: reentrant call");
        _locked = 1;
        _;
        _locked = 0;
    }

    function createMission(string calldata title, string calldata descriptionURI, string calldata category, uint64 deadline)
        external payable returns (uint256 id)
    {
        require(bytes(title).length > 0 && bytes(title).length <= MAX_TITLE_BYTES, "Evidara: invalid title");
        require(bytes(descriptionURI).length > 0 && bytes(descriptionURI).length <= MAX_URI_BYTES, "Evidara: invalid URI");
        require(bytes(category).length > 0 && bytes(category).length <= MAX_CATEGORY_BYTES, "Evidara: invalid category");
        require(deadline > block.timestamp && deadline <= block.timestamp + MAX_MISSION_LIFETIME, "Evidara: invalid deadline");
        require(msg.value > 0, "Evidara: bounty required");
        require(msg.value <= type(uint128).max, "Evidara: bounty too large");
        id = missionCount++;
        _missions[id] = Mission(msg.sender, title, descriptionURI, category, deadline, uint128(msg.value), 0, 0, 0, false);
        totalEscrowed += msg.value;
        emit MissionCreated(id, msg.sender, msg.value, deadline, title, category);
    }

    function fundMission(uint256 id) external payable validMission(id) {
        Mission storage m = _missions[id];
        require(!m.closed && block.timestamp < m.deadline, "Evidara: mission closed");
        require(msg.value > 0 && uint256(m.totalEscrowed) + msg.value <= type(uint128).max, "Evidara: invalid funding");
        m.totalEscrowed += uint128(msg.value);
        totalEscrowed += msg.value;
        emit MissionFunded(id, msg.sender, msg.value);
    }

    function contribute(uint256 id, string calldata evidenceURI) external validMission(id) returns (uint256 contributionId) {
        Mission storage m = _missions[id];
        require(!m.closed && block.timestamp < m.deadline, "Evidara: mission closed");
        require(bytes(evidenceURI).length > 0 && bytes(evidenceURI).length <= MAX_URI_BYTES, "Evidara: invalid URI");
        require(_contributions[id].length < type(uint32).max, "Evidara: too many contributions");
        contributionId = _contributions[id].length;
        _contributions[id].push(Contribution(msg.sender, evidenceURI, 0, 0, false));
        m.contributionCount++;
        emit ContributionSubmitted(id, contributionId, msg.sender, evidenceURI);
    }

    function approveContribution(uint256 id, uint256 contributionId, uint256 amount)
        external validMission(id)
    {
        Mission storage m = _missions[id];
        require(msg.sender == m.creator, "Evidara: creator only");
        require(!m.closed && block.timestamp < m.deadline, "Evidara: mission closed");
        require(contributionId < _contributions[id].length, "Evidara: invalid contribution");
        Contribution storage c = _contributions[id][contributionId];
        require(!c.approvedByCreator, "Evidara: already approved");
        require(amount > 0 && amount <= uint256(m.totalEscrowed) - uint256(m.totalAwarded), "Evidara: amount exceeds escrow");
        require(amount <= type(uint128).max, "Evidara: amount too large");
        c.approved = uint128(amount);
        c.approvedByCreator = true;
        m.totalAwarded += uint128(amount);
        totalAwarded += amount;
        claimable[c.contributor] += amount;
        emit ContributionApproved(id, contributionId, c.contributor, amount);
    }

    function claimRewards() external nonReentrant {
        uint256 amount = claimable[msg.sender];
        require(amount > 0, "Evidara: nothing to claim");
        claimable[msg.sender] = 0;
        totalClaimed += amount;
        (bool ok,) = payable(msg.sender).call{value: amount}("");
        require(ok, "Evidara: transfer failed");
        emit RewardsClaimed(msg.sender, amount);
    }

    function refundUnallocated(uint256 id) external validMission(id) nonReentrant {
        Mission storage m = _missions[id];
        require(msg.sender == m.creator, "Evidara: creator only");
        require(block.timestamp >= m.deadline && !m.closed, "Evidara: deadline not reached");
        m.closed = true;
        uint256 amount = uint256(m.totalEscrowed) - uint256(m.totalAwarded);
        m.totalEscrowed = m.totalAwarded;
        totalEscrowed -= amount;
        claimable[msg.sender] += amount;
        emit MissionRefunded(id, msg.sender, amount);
        emit MissionClosed(id);
    }

    function getMission(uint256 id) external view validMission(id) returns (Mission memory) { return _missions[id]; }
    function getContribution(uint256 id, uint256 contributionId) external view validMission(id) returns (Contribution memory) {
        require(contributionId < _contributions[id].length, "Evidara: invalid contribution");
        return _contributions[id][contributionId];
    }
    function getMissions(uint256 cursor, uint256 limit) external view returns (Mission[] memory result) {
        require(limit > 0 && limit <= MAX_PAGE_SIZE, "Evidara: invalid page size");
        if (cursor >= missionCount) return new Mission[](0);
        uint256 end = cursor + limit;
        if (end > missionCount) end = missionCount;
        result = new Mission[](end - cursor);
        for (uint256 i = cursor; i < end; i++) result[i - cursor] = _missions[i];
    }
    function getContributions(uint256 id, uint256 cursor, uint256 limit) external view validMission(id) returns (Contribution[] memory result) {
        require(limit > 0 && limit <= MAX_PAGE_SIZE, "Evidara: invalid page size");
        uint256 length = _contributions[id].length;
        if (cursor >= length) return new Contribution[](0);
        uint256 end = cursor + limit;
        if (end > length) end = length;
        result = new Contribution[](end - cursor);
        for (uint256 i = cursor; i < end; i++) result[i - cursor] = _contributions[id][i];
    }

    receive() external payable { revert("Evidara: use a mission function"); }
    fallback() external payable { revert("Evidara: unknown function"); }
}
