# Vercairn contract validation

Validated locally on 16 September 2026 for the Vercairn identity update. The current Hardhat run passed all **7 tests**, using only its in-process `hardhat` network. No deployment, public RPC verification, signing request or external transaction was performed. Machine-readable results, command output and hashes are in [VERCAIRN-VALIDATION.json](VERCAIRN-VALIDATION.json).

| Check | Result |
| --- | --- |
| Hardhat compile, Solidity 0.8.24, EVM Paris | Passed; 1 source compiled |
| Existing Hardhat suite | Passed; 7 tests |
| Source logic, excluding comments and whitespace | Identical to the preserved pre-update source |
| Creation and runtime executable bytecode | Identical after removing the compiler metadata trailer |
| Exported ABI and both website ABI copies | Byte-for-byte unchanged; each matches the current compiled ABI |
| Deployment record and Hardhat configuration | Byte-for-byte unchanged |
| Contract package identity | `vercairn-chain-contracts`; complete lockfile dependency records unchanged |
| Solidity change | Display comment only; `EvidaraEscrow` and `Evidara:` remain unchanged |

The suite covers mission creation, evidence submission, creator approval, pull claims, authorization, escrow limits, deadline restrictions, refunds, additional funding, pagination and direct-transfer rejection. These local checks do not establish the deployed bytecode at the recorded address.

From `contracts/`, reproduce the test run without opening private dotenv configuration:

```powershell
$env:NODE_OPTIONS = '--require ./scripts/local-test-isolation.cjs'
npm test -- --network hardhat
Remove-Item Env:NODE_OPTIONS
```

The preload disables `dotenv.config()` and removes the deployer private-key environment entry before the unchanged Hardhat configuration loads. It pins the local network. The validation did not read private configuration or credential files. The display comment changes compiler metadata, so complete bytecode hashes can differ while the executable bytes remain identical.

Historical evidence: [previous contract validation](archive/siftlane/README.md), [preserved source](archive/siftlane/EvidaraEscrow.sol) and [comparison hashes](archive/siftlane/pre-vercairn-baseline.json) retain the previous identity in their explicit archive. The earlier validation is not used as proof that the Vercairn website passed its current checks.
